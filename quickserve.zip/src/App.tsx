import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AndroidFrame } from './components/AndroidFrame';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeTab } from './components/HomeTab';
import { CategoriesTab } from './components/CategoriesTab';
import { BookingsTab } from './components/BookingsTab';
import { UCPlusTab } from './components/UCPlusTab';
import { AccountTab } from './components/AccountTab';
import { ServiceDetailModal } from './components/ServiceDetailModal';
import { CartModal } from './components/CartModal';
import { LocationPickerModal } from './components/LocationPickerModal';
import { PartnerContactModal } from './components/PartnerContactModal';
import { AuthModal } from './components/AuthModal';
import { ShoppingCart, ArrowRight } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { activeTab, cartCount, cartTotal, setIsCartOpen, notification } = useApp();

  return (
    <div className="flex flex-col h-full w-full relative overflow-hidden bg-neutral-100 select-none">
      {/* Top Header */}
      <Header />

      {/* Dynamic Tab Body */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {activeTab === 'home' && <HomeTab />}
        {activeTab === 'categories' && <CategoriesTab />}
        {activeTab === 'bookings' && <BookingsTab />}
        {activeTab === 'uc-plus' && <UCPlusTab />}
        {activeTab === 'account' && <AccountTab />}

        {/* Floating Quick Cart Bar (Classic QuickServe Mobile Pattern) */}
        {cartCount > 0 && activeTab !== 'bookings' && (
          <div className="absolute bottom-3 left-3 right-3 z-30 animate-in slide-in-from-bottom-3 duration-200">
            <button
              id="floating-cart-bar-btn"
              onClick={() => setIsCartOpen(true)}
              className="w-full bg-neutral-900 hover:bg-neutral-800 text-white rounded-2xl p-3 shadow-xl flex items-center justify-between transition-all border border-neutral-700 active:scale-98"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-500 text-neutral-950 flex items-center justify-center font-black text-xs">
                  {cartCount}
                </div>
                <div className="text-left">
                  <div className="text-xs font-bold leading-tight">
                    ₹{cartTotal}
                  </div>
                  <div className="text-[10px] text-neutral-400 leading-tight">
                    {cartCount} service{cartCount > 1 ? 's' : ''} added
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1 text-xs font-bold text-emerald-400">
                <span>View Cart</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </button>
          </div>
        )}
      </div>

      {/* Android Bottom Navigation */}
      <BottomNav />

      {/* Floating Toast Notification */}
      {notification && (
        <div className="absolute top-16 left-4 right-4 z-50 pointer-events-none animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="bg-neutral-900/95 text-white text-xs font-semibold px-3.5 py-2.5 rounded-xl shadow-xl backdrop-blur-md border border-neutral-700 flex items-center justify-between">
            <span>{notification}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          </div>
        </div>
      )}

      {/* Modals & Bottom Sheets */}
      <ServiceDetailModal />
      <CartModal />
      <LocationPickerModal />
      <PartnerContactModal />
      <AuthModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AndroidFrame>
        <MainAppContent />
      </AndroidFrame>
    </AppProvider>
  );
}
