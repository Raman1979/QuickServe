import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Category,
  Service,
  CartItem,
  Booking,
  Address,
  UserProfile,
  BookingStatus,
} from '../types';
import {
  INITIAL_CATEGORIES,
  ALL_SERVICES,
  DEFAULT_ADDRESS,
  MOCK_PARTNERS,
} from '../data/servicesData';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  onSnapshot,
  query,
  where,
} from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { uploadServicesToFirestore } from '../lib/firestoreSeed';

interface AppContextType {
  categories: Category[];
  services: Service[];
  isServicesLoading: boolean;
  isSeeding: boolean;
  seedServicesToFirestore: () => Promise<void>;
  cart: CartItem[];
  cartCount: number;
  cartTotal: number;
  cartOriginalTotal: number;
  tipAmount: number;
  setTipAmount: (amount: number) => void;
  addToCart: (service: Service) => void;
  removeFromCart: (serviceId: string) => void;
  clearCart: () => void;
  activeTab: 'home' | 'categories' | 'bookings' | 'uc-plus' | 'account';
  setActiveTab: (tab: 'home' | 'categories' | 'bookings' | 'uc-plus' | 'account') => void;
  selectedCategory: string;
  setSelectedCategory: (catId: string) => void;
  selectedSubCategory: string;
  setSelectedSubCategory: (subCatId: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedLocation: { city: string; area: string };
  setSelectedLocation: (loc: { city: string; area: string }) => void;
  activeAddress: Address;
  setActiveAddress: (addr: Address) => void;
  addresses: Address[];
  addAddress: (addr: Omit<Address, 'id'>) => void;
  firebaseUser: FirebaseUser | null;
  user: UserProfile | null;
  isLoggedIn: boolean;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  signupWithEmail: (email: string, pass: string, name: string, phone: string) => Promise<void>;
  loginWithPhoneOtp: (phone: string, otp: string) => Promise<void>;
  loginDemoUser: () => Promise<void>;
  logout: () => Promise<void>;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authModalMode: 'login' | 'signup' | 'phone';
  setAuthModalMode: (mode: 'login' | 'signup' | 'phone') => void;
  toggleUCPlus: () => void;
  bookings: Booking[];
  isBookingsLoading: boolean;
  createBooking: (
    timeSlot: string,
    scheduledDate: string,
    paymentMethod: string,
    paymentDetails?: {
      razorpayPaymentId?: string;
      razorpayOrderId?: string;
      paymentStatus?: 'paid' | 'pay_on_delivery';
    }
  ) => Promise<Booking | null>;
  cancelBooking: (bookingId: string) => void;
  advanceBookingStatus: (bookingId: string) => void;
  selectedServiceForDetail: Service | null;
  setSelectedServiceForDetail: (service: Service | null) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isLocationModalOpen: boolean;
  setIsLocationModalOpen: (open: boolean) => void;
  isPartnerModalOpen: boolean;
  setIsPartnerModalOpen: (open: boolean) => void;
  partnerModalBooking: Booking | null;
  setPartnerModalBooking: (b: Booking | null) => void;
  isDeviceFrame: boolean;
  setIsDeviceFrame: (enabled: boolean) => void;
  notification: string | null;
  showNotification: (msg: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [categories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [services, setServices] = useState<Service[]>(ALL_SERVICES);
  const [isServicesLoading, setIsServicesLoading] = useState<boolean>(true);
  const [isSeeding, setIsSeeding] = useState<boolean>(false);

  // Local storage loaded cart or default
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('uc_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [tipAmount, setTipAmount] = useState<number>(50);
  const [activeTab, setActiveTab] = useState<'home' | 'categories' | 'bookings' | 'uc-plus' | 'account'>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('ac-appliance');
  const [selectedSubCategory, setSelectedSubCategory] = useState<string>('ac-service');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  const [selectedLocation, setSelectedLocation] = useState<{ city: string; area: string }>(() => {
    try {
      const saved = localStorage.getItem('uc_loc');
      return saved ? JSON.parse(saved) : { city: 'Bengaluru', area: 'Indiranagar' };
    } catch {
      return { city: 'Bengaluru', area: 'Indiranagar' };
    }
  });

  const [addresses, setAddresses] = useState<Address[]>([DEFAULT_ADDRESS]);
  const [activeAddress, setActiveAddress] = useState<Address>(DEFAULT_ADDRESS);

  // Firebase Auth state
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('uc_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup' | 'phone'>('login');

  // Bookings state from Firestore
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isBookingsLoading, setIsBookingsLoading] = useState<boolean>(false);

  const [selectedServiceForDetail, setSelectedServiceForDetail] = useState<Service | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState<boolean>(false);
  const [isPartnerModalOpen, setIsPartnerModalOpen] = useState<boolean>(false);
  const [partnerModalBooking, setPartnerModalBooking] = useState<Booking | null>(null);
  const [isDeviceFrame, setIsDeviceFrame] = useState<boolean>(true);
  const [notification, setNotification] = useState<string | null>(null);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        // Fetch or create Firestore user record
        try {
          const userDocRef = doc(db, 'users', fbUser.uid);
          const docSnap = await getDoc(userDocRef);
          if (docSnap.exists()) {
            const data = docSnap.data();
            const profile: UserProfile = {
              uid: fbUser.uid,
              name: data.name || fbUser.displayName || 'QuickServe User',
              email: fbUser.email || data.email || '',
              phone: data.phone || fbUser.phoneNumber || '+91 98200 81234',
              isUCPlusMember: data.isUCPlusMember ?? true,
              plusExpiryDate: data.plusExpiryDate || 'Dec 2026',
              walletBalance: data.walletBalance ?? 450,
              totalSavings: data.totalSavings ?? 2840,
            };
            setUser(profile);
          } else {
            // Initialize document in Firestore
            const initialProfile: UserProfile = {
              uid: fbUser.uid,
              name: fbUser.displayName || 'QuickServe User',
              email: fbUser.email || '',
              phone: fbUser.phoneNumber || '+91 98200 81234',
              isUCPlusMember: false,
              plusExpiryDate: undefined,
              walletBalance: 100, // ₹100 Welcome Bonus!
              totalSavings: 0,
            };
            await setDoc(userDocRef, initialProfile);
            setUser(initialProfile);
          }
        } catch (err) {
          console.warn('Firestore profile sync fallback:', err);
          setUser({
            uid: fbUser.uid,
            name: fbUser.displayName || 'QuickServe User',
            email: fbUser.email || '',
            phone: fbUser.phoneNumber || '+91 98200 81234',
            isUCPlusMember: true,
            plusExpiryDate: 'Dec 2026',
            walletBalance: 250,
            totalSavings: 1500,
          });
        }
      } else {
        // If not logged in via Firebase, check if user has demo local user
        const localSaved = localStorage.getItem('uc_user');
        if (localSaved) {
          try {
            setUser(JSON.parse(localSaved));
          } catch {
            setUser(null);
          }
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Fetch services from Firestore in real time
  useEffect(() => {
    setIsServicesLoading(true);
    const servicesCol = collection(db, 'services');

    const unsubscribe = onSnapshot(
      servicesCol,
      async (snapshot) => {
        if (snapshot.empty) {
          try {
            setIsSeeding(true);
            await uploadServicesToFirestore();
          } catch (err) {
            console.warn('Firestore auto-seed error:', err);
            setServices(ALL_SERVICES);
            setIsServicesLoading(false);
          } finally {
            setIsSeeding(false);
          }
        } else {
          const fetched = snapshot.docs.map((d) => d.data() as Service);
          const fetchedIds = new Set(fetched.map((s) => s.id));
          const missing = ALL_SERVICES.filter((s) => !fetchedIds.has(s.id));

          if (missing.length > 0) {
            setServices([...fetched, ...missing]);
            setIsServicesLoading(false);
            // Asynchronously sync missing services to Firestore
            (async () => {
              for (const missingService of missing) {
                try {
                  await setDoc(
                    doc(servicesCol, missingService.id),
                    {
                      ...missingService,
                      updatedAt: new Date().toISOString(),
                    },
                    { merge: true }
                  );
                } catch (e) {
                  console.warn('Auto-seed missing service error:', e);
                }
              }
            })();
          } else {
            setServices(fetched);
            setIsServicesLoading(false);
          }
        }
      },
      (err) => {
        console.warn('Firestore services snapshot error:', err);
        setServices(ALL_SERVICES);
        setIsServicesLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  const seedServicesToFirestore = async () => {
    setIsSeeding(true);
    try {
      const res = await uploadServicesToFirestore();
      showNotification(`Uploaded ${res.count} services to Firestore!`);
    } catch (err: any) {
      console.error('Seed error:', err);
      showNotification(err?.message || 'Failed to seed services');
    } finally {
      setIsSeeding(false);
    }
  };

  // Fetch and listen only to the currently logged-in user's bookings from Firestore
  useEffect(() => {
    if (!user || !user.uid) {
      setBookings([]);
      setIsBookingsLoading(false);
      return;
    }

    setIsBookingsLoading(true);
    const bookingsCol = collection(db, 'bookings');
    const userBookingsQuery = query(bookingsCol, where('userId', '==', user.uid));

    const unsubscribe = onSnapshot(
      userBookingsQuery,
      (snapshot) => {
        if (snapshot.empty && user.uid === 'demo-aarav-mehta') {
          // Provide an initial active demo booking in Firestore for the demo account
          const sampleItem: CartItem = {
            service: ALL_SERVICES[0],
            quantity: 1,
          };
          const initialDemoBooking: Booking = {
            id: 'QS-98241',
            userId: user.uid,
            items: [sampleItem],
            totalAmount: 599,
            discountAmount: 150,
            tipAmount: 50,
            scheduledDate: 'Today',
            scheduledTimeSlot: '04:30 PM - 05:30 PM',
            address: DEFAULT_ADDRESS,
            paymentMethod: 'UPI (Google Pay)',
            paymentStatus: 'paid',
            status: 'partner_assigned',
            createdAt: new Date().toISOString(),
            partner: MOCK_PARTNERS[0],
            serviceOtp: '4892',
          };
          setDoc(doc(db, 'bookings', initialDemoBooking.id), initialDemoBooking).catch(console.warn);
          setBookings([initialDemoBooking]);
          setIsBookingsLoading(false);
          return;
        }

        const userBookings = snapshot.docs.map((docSnap) => docSnap.data() as Booking);
        userBookings.sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        setBookings(userBookings);
        setIsBookingsLoading(false);
      },
      (err) => {
        console.warn('Firestore bookings snapshot error:', err);
        setIsBookingsLoading(false);
      }
    );

    return () => unsubscribe();
  }, [user?.uid]);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('uc_cart', JSON.stringify(cart));
    } catch (e) {
      console.error(e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('uc_bookings', JSON.stringify(bookings));
    } catch (e) {
      console.error(e);
    }
  }, [bookings]);

  useEffect(() => {
    try {
      if (user) {
        localStorage.setItem('uc_user', JSON.stringify(user));
      } else {
        localStorage.removeItem('uc_user');
      }
    } catch (e) {
      console.error(e);
    }
  }, [user]);

  useEffect(() => {
    try {
      localStorage.setItem('uc_loc', JSON.stringify(selectedLocation));
    } catch (e) {
      console.error(e);
    }
  }, [selectedLocation]);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification((prev) => (prev === msg ? null : prev));
    }, 3000);
  };

  const loginWithEmail = async (email: string, pass: string) => {
    const cred = await signInWithEmailAndPassword(auth, email, pass);
    const profile: UserProfile = {
      uid: cred.user.uid,
      name: cred.user.displayName || email.split('@')[0],
      email: cred.user.email || email,
      phone: cred.user.phoneNumber || '+91 98200 81234',
      isUCPlusMember: true,
      plusExpiryDate: 'Dec 2026',
      walletBalance: 450,
      totalSavings: 2840,
    };
    setUser(profile);
    showNotification(`Welcome back, ${profile.name}!`);
  };

  const signupWithEmail = async (
    email: string,
    pass: string,
    name: string,
    phone: string
  ) => {
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    await updateProfile(cred.user, { displayName: name });
    const newProfile: UserProfile = {
      uid: cred.user.uid,
      name,
      email,
      phone,
      isUCPlusMember: true,
      plusExpiryDate: 'Sep 2027',
      walletBalance: 100, // ₹100 Welcome bonus
      totalSavings: 0,
    };
    try {
      await setDoc(doc(db, 'users', cred.user.uid), newProfile);
    } catch (e) {
      console.warn('Could not write to firestore immediately:', e);
    }
    setUser(newProfile);
    showNotification(`Account created! Welcome, ${name}!`);
  };

  const loginWithPhoneOtp = async (phone: string, otp: string) => {
    if (otp !== '4892' && otp.length < 4) {
      throw new Error('Invalid OTP code. Try demo code: 4892');
    }
    const phoneUser: UserProfile = {
      uid: `phone-${Date.now()}`,
      name: `User ${phone.slice(-4)}`,
      email: `${phone.replace(/\D/g, '')}@quickserve.in`,
      phone: phone.startsWith('+91') ? phone : `+91 ${phone}`,
      isUCPlusMember: true,
      plusExpiryDate: 'Dec 2026',
      walletBalance: 300,
      totalSavings: 1200,
    };
    setUser(phoneUser);
    showNotification(`Logged in via OTP as ${phoneUser.phone}!`);
  };

  const loginDemoUser = async () => {
    const demoProfile: UserProfile = {
      uid: 'demo-aarav-mehta',
      name: 'Aarav Mehta',
      email: 'aarav.mehta@example.com',
      phone: '+91 98200 81234',
      isUCPlusMember: true,
      plusExpiryDate: 'Dec 2026',
      walletBalance: 450,
      totalSavings: 2840,
    };
    setUser(demoProfile);
    showNotification('Logged in as Demo User (Aarav Mehta)');
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error(e);
    }
    setUser(null);
    setFirebaseUser(null);
    localStorage.removeItem('uc_user');
    showNotification('You have logged out successfully');
  };

  const addToCart = (service: Service) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.service.id === service.id);
      if (existing) {
        return prev.map((item) =>
          item.service.id === service.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { service, quantity: 1 }];
    });
    showNotification(`Added "${service.name.slice(0, 24)}..." to cart`);
  };

  const removeFromCart = (serviceId: string) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.service.id === serviceId);
      if (existing && existing.quantity > 1) {
        return prev.map((item) =>
          item.service.id === serviceId ? { ...item, quantity: item.quantity - 1 } : item
        );
      }
      return prev.filter((item) => item.service.id !== serviceId);
    });
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const cartTotal = cart.reduce((acc, item) => acc + item.service.price * item.quantity, 0);
  const cartOriginalTotal = cart.reduce(
    (acc, item) => acc + (item.service.originalPrice || item.service.price) * item.quantity,
    0
  );

  const toggleUCPlus = () => {
    if (!user) {
      setIsAuthModalOpen(true);
      showNotification('Please login to manage QuickServe Plus membership');
      return;
    }

    setUser((prev) => {
      if (!prev) return null;
      const nextStatus = !prev.isUCPlusMember;
      const updated = {
        ...prev,
        isUCPlusMember: nextStatus,
        plusExpiryDate: nextStatus ? 'Sep 2027' : undefined,
      };
      if (prev.uid && firebaseUser) {
        updateDoc(doc(db, 'users', prev.uid), {
          isUCPlusMember: nextStatus,
          plusExpiryDate: nextStatus ? 'Sep 2027' : null,
        }).catch((err) => console.warn(err));
      }
      return updated;
    });

    showNotification(
      user.isUCPlusMember ? 'QuickServe Plus membership paused' : 'Welcome to QuickServe Plus! 15% extra off applied'
    );
  };

  const addAddress = (addrData: Omit<Address, 'id'>) => {
    const newAddr: Address = {
      ...addrData,
      id: `addr-${Date.now()}`,
    };
    setAddresses((prev) => [...prev, newAddr]);
    setActiveAddress(newAddr);
    showNotification('New address saved successfully');
  };

  const createBooking = async (
    timeSlot: string,
    scheduledDate: string,
    paymentMethod: string,
    paymentDetails?: {
      razorpayPaymentId?: string;
      razorpayOrderId?: string;
      paymentStatus?: 'paid' | 'pay_on_delivery';
    }
  ): Promise<Booking | null> => {
    if (!user) {
      setIsAuthModalOpen(true);
      showNotification('Please login to complete your booking');
      return null;
    }

    const plusDiscount = user?.isUCPlusMember ? Math.round(cartTotal * 0.12) : 0;
    const taxesAndFee = cart.length > 0 ? 49 : 0;
    const finalAmount = Math.max(0, cartTotal - plusDiscount + taxesAndFee + tipAmount);
    
    // Assign random top partner
    const assignedPartner = MOCK_PARTNERS[Math.floor(Math.random() * MOCK_PARTNERS.length)];
    const generatedOtp = Math.floor(1000 + Math.random() * 9000).toString();

    const newBooking: Booking = {
      id: `QS-${Math.floor(10000 + Math.random() * 90000)}`,
      userId: user.uid,
      items: [...cart],
      totalAmount: finalAmount,
      discountAmount: plusDiscount,
      tipAmount,
      scheduledDate,
      scheduledTimeSlot: timeSlot,
      address: activeAddress,
      paymentMethod,
      paymentStatus: paymentDetails?.paymentStatus || (paymentMethod === 'Cash after service' ? 'pay_on_delivery' : 'paid'),
      status: 'confirmed',
      createdAt: new Date().toISOString(),
      partner: assignedPartner,
      serviceOtp: generatedOtp,
      razorpayPaymentId: paymentDetails?.razorpayPaymentId,
      razorpayOrderId: paymentDetails?.razorpayOrderId,
    };

    // Save directly into Firestore 'bookings' collection
    try {
      const bookingDocRef = doc(db, 'bookings', newBooking.id);
      await setDoc(bookingDocRef, newBooking);
    } catch (err) {
      console.error('Error saving booking to Firestore:', err);
    }

    setBookings((prev) => [newBooking, ...prev.filter((b) => b.id !== newBooking.id)]);
    clearCart();
    setIsCartOpen(false);
    setActiveTab('bookings');
    showNotification(`Booking ${newBooking.id} placed & saved to Firestore!`);

    // Simulate partner assignment after 3.5 seconds
    setTimeout(async () => {
      setBookings((prev) =>
        prev.map((b) => (b.id === newBooking.id ? { ...b, status: 'partner_assigned' } : b))
      );
      try {
        await updateDoc(doc(db, 'bookings', newBooking.id), { status: 'partner_assigned' });
      } catch (err) {
        // silent
      }
    }, 3500);

    return newBooking;
  };

  const cancelBooking = async (bookingId: string) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, status: 'cancelled' } : b))
    );
    try {
      await updateDoc(doc(db, 'bookings', bookingId), { status: 'cancelled' });
    } catch (e) {
      console.warn('Failed to cancel booking in Firestore:', e);
    }
    showNotification('Booking has been cancelled');
  };

  const advanceBookingStatus = async (bookingId: string) => {
    const statusSequence: BookingStatus[] = [
      'confirmed',
      'partner_assigned',
      'on_the_way',
      'in_progress',
      'completed',
    ];
    let targetStatus: BookingStatus | null = null;
    setBookings((prev) =>
      prev.map((b) => {
        if (b.id === bookingId && b.status !== 'cancelled' && b.status !== 'completed') {
          const currentIndex = statusSequence.indexOf(b.status);
          const nextStatus = statusSequence[currentIndex + 1] || 'completed';
          targetStatus = nextStatus;
          return { ...b, status: nextStatus };
        }
        return b;
      })
    );
    if (targetStatus) {
      try {
        await updateDoc(doc(db, 'bookings', bookingId), { status: targetStatus });
      } catch (e) {
        console.warn('Failed to advance booking in Firestore:', e);
      }
      showNotification(`Booking updated to "${(targetStatus as string).replace('_', ' ')}"`);
    }
  };

  return (
    <AppContext.Provider
      value={{
        categories,
        services,
        isServicesLoading,
        isSeeding,
        seedServicesToFirestore,
        cart,
        cartCount,
        cartTotal,
        cartOriginalTotal,
        tipAmount,
        setTipAmount,
        addToCart,
        removeFromCart,
        clearCart,
        activeTab,
        setActiveTab,
        selectedCategory,
        setSelectedCategory,
        selectedSubCategory,
        setSelectedSubCategory,
        searchQuery,
        setSearchQuery,
        selectedLocation,
        setSelectedLocation,
        activeAddress,
        setActiveAddress,
        addresses,
        addAddress,
        firebaseUser,
        user,
        isLoggedIn: Boolean(user),
        loginWithEmail,
        signupWithEmail,
        loginWithPhoneOtp,
        loginDemoUser,
        logout,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authModalMode,
        setAuthModalMode,
        toggleUCPlus,
        bookings,
        isBookingsLoading,
        createBooking,
        cancelBooking,
        advanceBookingStatus,
        selectedServiceForDetail,
        setSelectedServiceForDetail,
        isCartOpen,
        setIsCartOpen,
        isLocationModalOpen,
        setIsLocationModalOpen,
        isPartnerModalOpen,
        setIsPartnerModalOpen,
        partnerModalBooking,
        setPartnerModalBooking,
        isDeviceFrame,
        setIsDeviceFrame,
        notification,
        showNotification,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
