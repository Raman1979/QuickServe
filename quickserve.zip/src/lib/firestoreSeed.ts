import { collection, doc, setDoc, getDocs } from 'firebase/firestore';
import { db } from './firebase';
import { ALL_SERVICES } from '../data/servicesData';
import { Service } from '../types';

export async function uploadServicesToFirestore(): Promise<{ count: number }> {
  const servicesCol = collection(db, 'services');
  let count = 0;

  for (const service of ALL_SERVICES) {
    const serviceDocRef = doc(servicesCol, service.id);
    await setDoc(
      serviceDocRef,
      {
        ...service,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
    count++;
  }

  return { count };
}

export async function getServicesFromFirestore(): Promise<Service[]> {
  const servicesCol = collection(db, 'services');
  const snapshot = await getDocs(servicesCol);
  
  if (snapshot.empty) {
    return [];
  }

  return snapshot.docs.map((docSnap) => docSnap.data() as Service);
}
