export interface Service {
  id: string;
  categoryId: string;
  subCategoryId: string;
  name: string;
  tagline?: string;
  rating: number;
  reviewCount: number;
  price: number;
  originalPrice?: number;
  durationMinutes: number;
  image: string;
  description: string;
  inclusions: string[];
  exclusions?: string[];
  features?: string[];
  badge?: string;
  isPopular?: boolean;
}

export interface SubCategory {
  id: string;
  name: string;
  iconName: string;
}

export interface Category {
  id: string;
  name: string;
  shortName: string;
  icon: string;
  color: string;
  bannerImage: string;
  subCategories: SubCategory[];
}

export interface CartItem {
  service: Service;
  quantity: number;
  selectedOptions?: Record<string, string>;
}

export type BookingStatus =
  | 'confirmed'
  | 'partner_assigned'
  | 'on_the_way'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export interface ProfessionalPartner {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  totalJobs: number;
  experienceYears: number;
  phone: string;
  vaccinationStatus: string;
  badges: string[];
}

export interface Booking {
  id: string;
  userId: string;
  items: CartItem[];
  totalAmount: number;
  discountAmount: number;
  tipAmount: number;
  scheduledDate: string;
  scheduledTimeSlot: string;
  address: Address;
  paymentMethod: string;
  paymentStatus: 'paid' | 'pay_on_delivery';
  status: BookingStatus;
  createdAt: string;
  partner?: ProfessionalPartner;
  serviceOtp: string;
  razorpayPaymentId?: string;
  razorpayOrderId?: string;
}

export interface Address {
  id: string;
  label: 'Home' | 'Work' | 'Other';
  flatNo: string;
  building: string;
  street: string;
  city: string;
  pincode: string;
  isDefault?: boolean;
}

export interface UserProfile {
  uid?: string;
  name: string;
  phone: string;
  email: string;
  isUCPlusMember: boolean;
  plusExpiryDate?: string;
  walletBalance: number;
  totalSavings: number;
}
