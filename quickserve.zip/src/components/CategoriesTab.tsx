import React from 'react';
import {
  Star,
  Plus,
  Minus,
  Check,
  Clock,
  Sparkles,
  AirVent,
  ShowerHead,
  UserCheck,
  Wrench,
  ShieldCheck,
  Loader2,
  Hammer,
  Car,
  Shield,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const CategoriesTab: React.FC = () => {
  const {
    categories,
    services,
    isServicesLoading,
    cart,
    addToCart,
    removeFromCart,
    selectedCategory,
    setSelectedCategory,
    selectedSubCategory,
    setSelectedSubCategory,
    setSelectedServiceForDetail,
  } = useApp();

  const currentCategoryObj =
    categories.find((c) => c.id === selectedCategory) || categories[0];

  const filteredServices = services.filter((s) => {
    if (s.categoryId !== selectedCategory) return false;
    if (selectedSubCategory && s.subCategoryId !== selectedSubCategory) return false;
    return true;
  });

  const getCategoryIcon = (id: string) => {
    switch (id) {
      case 'ac-appliance':
        return <AirVent className="w-4 h-4" />;
      case 'women-salon':
        return <Sparkles className="w-4 h-4" />;
      case 'cleaning-pest':
        return <ShowerHead className="w-4 h-4" />;
      case 'men-salon':
        return <UserCheck className="w-4 h-4" />;
      case 'handyman-construction':
        return <Hammer className="w-4 h-4" />;
      case 'vehicle-care':
        return <Car className="w-4 h-4" />;
      case 'home-help-security':
        return <Shield className="w-4 h-4" />;
      case 'electrician-plumber':
        return <Wrench className="w-4 h-4" />;
      case 'native-products':
        return <ShieldCheck className="w-4 h-4" />;
      default:
        return <Sparkles className="w-4 h-4" />;
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-neutral-100">
      {/* Horizontal Top Category Pills */}
      <div className="bg-white border-b border-neutral-200 px-3 py-2 shrink-0 overflow-x-auto no-scrollbar flex items-center gap-2">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              id={`cat-pill-${cat.id}`}
              onClick={() => {
                setSelectedCategory(cat.id);
                if (cat.subCategories.length > 0) {
                  setSelectedSubCategory(cat.subCategories[0].id);
                }
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all ${
                isSelected
                  ? 'bg-neutral-900 text-white shadow-xs'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              {getCategoryIcon(cat.id)}
              <span>{cat.shortName}</span>
            </button>
          );
        })}
      </div>

      {/* Main Content Area: Left Subcategory rail + Right Service List */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Subcategory Rail */}
        <aside className="w-24 sm:w-28 bg-white border-r border-neutral-200 overflow-y-auto no-scrollbar shrink-0 py-2">
          {currentCategoryObj.subCategories.map((subCat) => {
            const isSelected = selectedSubCategory === subCat.id;
            return (
              <button
                key={subCat.id}
                id={`subcat-btn-${subCat.id}`}
                onClick={() => setSelectedSubCategory(subCat.id)}
                className={`w-full py-3 px-2 text-left flex flex-col items-center justify-center transition-colors relative ${
                  isSelected
                    ? 'bg-neutral-50 text-neutral-950 font-bold'
                    : 'text-neutral-500 hover:bg-neutral-50/50'
                }`}
              >
                {isSelected && (
                  <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-7 bg-neutral-900 rounded-r-md" />
                )}
                <span className="text-[10px] text-center leading-tight">
                  {subCat.name}
                </span>
              </button>
            );
          })}
        </aside>

        {/* Right Service List */}
        <div className="flex-1 overflow-y-auto no-scrollbar p-3 space-y-3 pb-24">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-extrabold text-neutral-900 uppercase tracking-wide">
              {currentCategoryObj.subCategories.find((s) => s.id === selectedSubCategory)?.name ||
                currentCategoryObj.name}
            </h2>
            <span className="text-[10px] text-neutral-400 font-medium">
              {isServicesLoading ? 'Syncing...' : `${filteredServices.length} options`}
            </span>
          </div>

          {isServicesLoading ? (
            <div className="py-20 flex flex-col items-center justify-center space-y-3 bg-white rounded-2xl border border-neutral-200 p-6 text-center shadow-2xs">
              <Loader2 className="w-8 h-8 text-neutral-900 animate-spin" />
              <div className="space-y-1">
                <p className="text-xs font-bold text-neutral-900">
                  Loading catalog from Firestore...
                </p>
                <p className="text-[10px] text-neutral-500">
                  Fetching services for {currentCategoryObj.name}
                </p>
              </div>
            </div>
          ) : filteredServices.length === 0 ? (
            <div className="py-12 text-center bg-white rounded-2xl border border-neutral-200 p-4">
              <p className="text-xs font-semibold text-neutral-500">
                No services listed under this sub-category yet.
              </p>
              <button
                id="reset-subcat-btn"
                onClick={() =>
                  setSelectedSubCategory(currentCategoryObj.subCategories[0]?.id || '')
                }
                className="mt-2 text-xs text-neutral-900 font-bold underline"
              >
                View all options
              </button>
            </div>
          ) : (
            filteredServices.map((service) => {
              const cartItem = cart.find((item) => item.service.id === service.id);
              const qty = cartItem ? cartItem.quantity : 0;

              return (
                <div
                  key={service.id}
                  id={`cat-service-card-${service.id}`}
                  className="bg-white rounded-2xl p-3 border border-neutral-200 shadow-xs flex flex-col justify-between hover:shadow-md transition-shadow"
                >
                  <div className="flex gap-3">
                    <div
                      className="flex-1 cursor-pointer"
                      onClick={() => setSelectedServiceForDetail(service)}
                    >
                      {service.badge && (
                        <span className="inline-block text-[9px] font-bold bg-neutral-900 text-white px-1.5 py-0.5 rounded uppercase tracking-wider mb-1">
                          {service.badge}
                        </span>
                      )}
                      <h3 className="text-xs font-bold text-neutral-900 leading-snug">
                        {service.name}
                      </h3>

                      <div className="flex items-center gap-1.5 mt-1">
                        <div className="flex items-center gap-0.5 text-[10px] font-bold text-neutral-800">
                          <Star className="w-2.5 h-2.5 text-amber-500 fill-amber-500" />
                          <span>{service.rating}</span>
                        </div>
                        <span className="text-neutral-300">•</span>
                        <span className="text-[10px] text-neutral-500 flex items-center gap-0.5">
                          <Clock className="w-2.5 h-2.5" />
                          {service.durationMinutes}m
                        </span>
                      </div>

                      <div className="flex items-baseline gap-1.5 mt-1.5">
                        <span className="text-sm font-black text-neutral-900">
                          ₹{service.price}
                        </span>
                        {service.originalPrice && (
                          <span className="text-[11px] text-neutral-400 line-through">
                            ₹{service.originalPrice}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Image & Add button */}
                    <div className="flex flex-col items-center shrink-0 w-20">
                      <div
                        className="w-20 h-16 rounded-xl overflow-hidden cursor-pointer relative shadow-xs"
                        onClick={() => setSelectedServiceForDetail(service)}
                      >
                        <img
                          src={service.image}
                          alt={service.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      <div className="-mt-3 z-10">
                        {qty === 0 ? (
                          <button
                            id={`cat-add-btn-${service.id}`}
                            onClick={() => addToCart(service)}
                            className="bg-white border border-emerald-600 text-emerald-700 font-bold text-[11px] px-3.5 py-0.5 rounded-lg shadow-sm hover:bg-emerald-50 transition-colors uppercase tracking-wider"
                          >
                            Add
                          </button>
                        ) : (
                          <div className="bg-emerald-600 text-white font-bold text-[11px] px-2 py-0.5 rounded-lg shadow-sm flex items-center gap-2">
                            <button
                              id={`cat-minus-btn-${service.id}`}
                              onClick={() => removeFromCart(service.id)}
                              className="hover:opacity-80 p-0.5"
                            >
                              <Minus className="w-2.5 h-2.5" />
                            </button>
                            <span>{qty}</span>
                            <button
                              id={`cat-plus-btn-${service.id}`}
                              onClick={() => addToCart(service)}
                              className="hover:opacity-80 p-0.5"
                            >
                              <Plus className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Bullet inclusions preview */}
                  <div
                    className="mt-2.5 pt-2 border-t border-neutral-100 cursor-pointer"
                    onClick={() => setSelectedServiceForDetail(service)}
                  >
                    <ul className="space-y-1">
                      {service.inclusions.slice(0, 2).map((inc, i) => (
                        <li
                          key={i}
                          className="text-[10px] text-neutral-600 flex items-center gap-1 leading-tight line-clamp-1"
                        >
                          <Check className="w-3 h-3 text-emerald-600 shrink-0" />
                          <span>{inc}</span>
                        </li>
                      ))}
                    </ul>
                    <span className="text-[10px] font-bold text-neutral-400 hover:text-neutral-700 mt-1 inline-block">
                      View details &gt;
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
