import React, { useState } from 'react';
import {
  X,
  MapPin,
  Clock,
  Phone,
  MessageSquare,
  KeyRound,
  ShieldCheck,
  CheckCircle2,
  ChevronRight,
  AlertCircle,
  Sparkles,
  Copy,
  Check,
  CreditCard,
  Calendar,
  UserCheck,
  Star,
} from 'lucide-react';
import { Booking, BookingStatus } from '../types';
import { PartnerTrackingMap } from './PartnerTrackingMap';
import { useApp } from '../context/AppContext';

interface BookingStatusModalProps {
  booking: Booking | null;
  isOpen: boolean;
  onClose: () => void;
}

const statusSteps: { key: BookingStatus; label: string; desc: string }[] = [
  { key: 'confirmed', label: 'Booking Confirmed', desc: 'Partner assigned & preparing kit' },
  { key: 'partner_assigned', label: 'Partner Assigned', desc: 'Vaccinated professional on stand-by' },
  { key: 'on_the_way', label: 'Partner On The Way', desc: 'Riding towards your location' },
  { key: 'in_progress', label: 'Service In Progress', desc: 'Work underway with hygiene standards' },
  { key: 'completed', label: 'Service Completed', desc: 'Quality checked & 30-day warranty active' },
];

export const BookingStatusModal: React.FC<BookingStatusModalProps> = ({
  booking,
  isOpen,
  onClose,
}) => {
  const { advanceBookingStatus, cancelBooking, showNotification } = useApp();
  const [copiedOtp, setCopiedOtp] = useState(false);

  if (!isOpen || !booking) return null;

  const currentStepIdx = statusSteps.findIndex((s) => s.key === booking.status);
  const isCancelled = booking.status === 'cancelled';
  const isCompleted = booking.status === 'completed';

  const handleCopyOtp = () => {
    if (booking?.serviceOtp) {
      navigator.clipboard?.writeText(booking.serviceOtp);
      setCopiedOtp(true);
      showNotification('OTP copied to clipboard!');
      setTimeout(() => setCopiedOtp(false), 2000);
    }
  };

  const handleAdvanceStep = () => {
    advanceBookingStatus(booking.id);
    showNotification('Service status advanced and synced to Firestore!');
  };

  const handleCancel = () => {
    if (confirm('Are you sure you want to cancel this booking?')) {
      cancelBooking(booking.id);
      showNotification('Booking cancelled.');
      onClose();
    }
  };

  return (
    <div
      id="booking-status-modal-backdrop"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-xs p-0 sm:p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div
        id="booking-status-modal"
        className="w-full max-w-xl bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] sm:max-h-[88vh] animate-in slide-in-from-bottom-6 sm:zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 bg-neutral-900 text-white flex items-center justify-between shrink-0 border-b border-neutral-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-emerald-400">
                {booking.id}
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-neutral-800 text-neutral-300">
                {booking.paymentStatus === 'paid' ? 'Paid Online' : 'Pay After Service'}
              </span>
              {booking.razorpayPaymentId && (
                <span className="text-[9px] bg-[#3395ff]/30 text-[#8ec2ff] px-1.5 py-0.5 rounded font-mono">
                  RZP TEST
                </span>
              )}
            </div>
            <div className="text-xs text-neutral-300 mt-1 flex items-center gap-1.5 font-medium">
              <Calendar className="w-3.5 h-3.5 text-neutral-400" />
              <span>
                {booking.scheduledDate} • {booking.scheduledTimeSlot}
              </span>
            </div>
          </div>

          <button
            id="close-booking-status-modal-btn"
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white rounded-full hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
          {/* Live Tracking Map Component */}
          {!isCancelled && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-neutral-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>Live Partner Route Tracking</span>
                </span>
                <span className="text-[10px] text-neutral-500 font-medium">
                  Simulated via OpenStreetMap
                </span>
              </div>

              <PartnerTrackingMap
                address={booking.address}
                partner={booking.partner}
                status={booking.status}
                onPartnerArrived={() => {
                  if (booking.status === 'on_the_way') {
                    advanceBookingStatus(booking.id);
                  }
                }}
              />
            </div>
          )}

          {/* Start Service OTP Banner */}
          {!isCompleted && !isCancelled && (
            <div className="p-3.5 bg-gradient-to-r from-amber-50 to-amber-100/60 border border-amber-200 rounded-2xl flex items-center justify-between shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500 text-neutral-950 flex items-center justify-center font-bold shadow-xs">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-wider text-amber-900">
                    Start Service OTP
                  </div>
                  <div className="text-xs text-amber-800 font-medium">
                    Share with {booking.partner?.name || 'partner'} upon arrival
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-base font-black font-mono tracking-widest bg-white px-3 py-1.5 rounded-xl border border-amber-300 text-amber-950 shadow-inner">
                  {booking.serviceOtp}
                </span>
                <button
                  type="button"
                  id="copy-otp-btn"
                  onClick={handleCopyOtp}
                  title="Copy OTP"
                  className="p-2 bg-white hover:bg-amber-100/50 rounded-xl border border-amber-200 text-amber-800 transition-colors"
                >
                  {copiedOtp ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          {/* Assigned Professional Profile Card */}
          {booking.partner && !isCancelled && (
            <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img
                      src={booking.partner.avatar}
                      alt={booking.partner.name}
                      className="w-14 h-14 rounded-full object-cover ring-2 ring-emerald-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute -bottom-1 -right-1 bg-emerald-500 text-white rounded-full p-0.5 border border-white">
                      <ShieldCheck className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-sm font-extrabold text-neutral-900">
                        {booking.partner.name}
                      </h4>
                      <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">
                        Verified
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-neutral-600 mt-0.5">
                      <span className="flex items-center gap-0.5 font-bold text-neutral-900">
                        <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                        {booking.partner.rating}
                      </span>
                      <span>•</span>
                      <span>{booking.partner.totalJobs} jobs</span>
                      <span>•</span>
                      <span className="text-emerald-700 font-semibold">Clean Kit Ready</span>
                    </div>

                    <div className="text-[11px] text-neutral-500 mt-1">
                      Transport: Honda Activa (Scooter) • Tool Kit Bag
                    </div>
                  </div>
                </div>

                {/* Call & Chat */}
                <div className="flex flex-col sm:flex-row gap-1.5">
                  <button
                    type="button"
                    id="partner-call-btn"
                    onClick={() =>
                      showNotification(`Calling ${booking.partner?.name}: ${booking.partner?.phone}`)
                    }
                    className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-colors flex items-center justify-center gap-1"
                    title="Call"
                  >
                    <Phone className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    id="partner-chat-btn"
                    onClick={() =>
                      showNotification(`Chat session initiated with ${booking.partner?.name}`)
                    }
                    className="p-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white shadow-xs transition-colors flex items-center justify-center gap-1"
                    title="Chat"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Stepper Timeline & Simulator Button */}
          {!isCancelled && (
            <div className="p-4 bg-white border border-neutral-200 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
                  Service Lifecycle
                </span>
                {!isCompleted && (
                  <button
                    type="button"
                    id="status-screen-advance-btn"
                    onClick={handleAdvanceStep}
                    className="text-xs font-bold bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200 px-3 py-1 rounded-lg transition-colors flex items-center gap-1"
                  >
                    <span>Advance Status</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="relative pl-6 space-y-3.5">
                <div className="absolute left-2.5 top-2 bottom-2 w-0.5 bg-neutral-200" />
                {statusSteps.map((step, idx) => {
                  const isDone = currentStepIdx >= idx;
                  const isCurrent = currentStepIdx === idx;

                  return (
                    <div key={step.key} className="relative flex items-start gap-3">
                      <span
                        className={`absolute -left-6 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold transition-all ${
                          isDone
                            ? 'bg-emerald-600 text-white ring-2 ring-emerald-100'
                            : 'bg-neutral-200 text-neutral-600'
                        } ${isCurrent ? 'ring-4 ring-emerald-200 animate-pulse' : ''}`}
                      >
                        {isDone ? '✓' : idx + 1}
                      </span>
                      <div className="flex-1">
                        <div
                          className={`text-xs font-bold leading-tight ${
                            isDone ? 'text-neutral-900' : 'text-neutral-400'
                          }`}
                        >
                          {step.label}
                        </div>
                        <div className="text-[10px] text-neutral-500 leading-tight mt-0.5">
                          {step.desc}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Booked Services Summary */}
          <div className="p-4 bg-neutral-50 border border-neutral-200 rounded-2xl space-y-2.5">
            <span className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
              Booked Items ({booking.items.length})
            </span>

            <div className="space-y-2">
              {booking.items.map((item) => (
                <div
                  key={item.service.id}
                  className="flex items-center gap-3 bg-white p-2.5 rounded-xl border border-neutral-200"
                >
                  <img
                    src={item.service.image}
                    alt={item.service.name}
                    className="w-12 h-12 rounded-lg object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1">
                    <div className="text-xs font-bold text-neutral-900">{item.service.name}</div>
                    <div className="text-[11px] text-neutral-500">
                      Qty: {item.quantity} • ₹{item.service.price * item.quantity}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Address & Payment Details */}
            <div className="pt-2 border-t border-neutral-200 text-xs space-y-1 text-neutral-600">
              <div className="flex items-start gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0 mt-0.5" />
                <span>
                  <strong>{booking.address.label}:</strong> {booking.address.flatNo},{' '}
                  {booking.address.building}, {booking.address.street}, {booking.address.city} -{' '}
                  {booking.address.pincode}
                </span>
              </div>
              <div className="flex items-center justify-between pt-1 font-bold text-neutral-900">
                <span>Total Amount</span>
                <span className="text-sm">₹{booking.totalAmount}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Footer Actions */}
        <div className="p-3 bg-neutral-50 border-t border-neutral-200 flex items-center justify-between shrink-0">
          {!isCompleted && !isCancelled ? (
            <button
              type="button"
              id="status-modal-cancel-btn"
              onClick={handleCancel}
              className="text-xs font-bold text-rose-600 hover:text-rose-700 hover:underline px-2 py-1"
            >
              Cancel Booking
            </button>
          ) : (
            <span className="text-xs text-neutral-500">
              {isCancelled ? 'Booking Cancelled' : 'Completed with 30-Day Warranty'}
            </span>
          )}

          <button
            type="button"
            id="status-modal-done-btn"
            onClick={onClose}
            className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
