import React, { useState } from 'react';
import {
  Clock,
  Phone,
  MessageSquare,
  CheckCircle2,
  Calendar,
  AlertCircle,
  KeyRound,
  RotateCcw,
  ShieldCheck,
  Star,
  ChevronRight,
  Sparkles,
  Loader2,
  LogIn,
  CreditCard,
  Navigation,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Booking, BookingStatus } from '../types';
import { BookingStatusModal } from './BookingStatusModal';

export const BookingsTab: React.FC = () => {
  const {
    user,
    bookings,
    isBookingsLoading,
    cancelBooking,
    advanceBookingStatus,
    setPartnerModalBooking,
    setIsPartnerModalOpen,
    setIsAuthModalOpen,
    setActiveTab,
    setSelectedCategory,
  } = useApp();

  const [bookingFilter, setBookingFilter] = useState<'active' | 'past'>('active');
  const [selectedBookingForStatus, setSelectedBookingForStatus] = useState<Booking | null>(null);

  const activeBookings = bookings.filter(
    (b) => b.status !== 'completed' && b.status !== 'cancelled'
  );
  const pastBookings = bookings.filter(
    (b) => b.status === 'completed' || b.status === 'cancelled'
  );

  const displayedList = bookingFilter === 'active' ? activeBookings : pastBookings;
  const activeBookingInModal = bookings.find((b) => b.id === selectedBookingForStatus?.id) || selectedBookingForStatus;

  const getStatusStepIndex = (status: BookingStatus) => {
    switch (status) {
      case 'confirmed':
        return 0;
      case 'partner_assigned':
        return 1;
      case 'on_the_way':
        return 2;
      case 'in_progress':
        return 3;
      case 'completed':
        return 4;
      default:
        return 0;
    }
  };

  const statusSteps = [
    { label: 'Booking Placed', desc: 'Request confirmed' },
    { label: 'Partner Assigned', desc: 'Vaccinated pro allocated' },
    { label: 'On The Way', desc: 'Tracking arrival' },
    { label: 'Service In Progress', desc: 'Job started' },
    { label: 'Completed', desc: 'Payment settled' },
  ];

  const handleContactPartner = (booking: Booking) => {
    setPartnerModalBooking(booking);
    setIsPartnerModalOpen(true);
  };

  if (!user) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 bg-neutral-100 text-center">
        <div className="bg-white p-6 rounded-3xl border border-neutral-200 shadow-sm max-w-sm w-full space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-neutral-900 text-white flex items-center justify-center mx-auto shadow-md">
            <Calendar className="w-7 h-7" />
          </div>
          <div className="space-y-1.5">
            <h2 className="text-base font-extrabold text-neutral-900">
              Track Your Bookings
            </h2>
            <p className="text-xs text-neutral-500 leading-relaxed">
              Log in to view your scheduled services, live partner location, and service OTPs saved in the Firestore database.
            </p>
          </div>
          <button
            id="bookings-login-btn"
            onClick={() => setIsAuthModalOpen(true)}
            className="w-full py-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs uppercase tracking-wider transition-colors shadow-xs flex items-center justify-center gap-2 active:scale-95"
          >
            <LogIn className="w-4 h-4" />
            <span>Login to View Bookings</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-neutral-100">
      {/* Top Filter Buttons */}
      <div className="bg-white border-b border-neutral-200 px-4 py-2.5 flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-sm font-extrabold text-neutral-900 tracking-tight">
            My Bookings
          </h1>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] text-neutral-500 font-medium">
              Firestore: <span className="font-mono text-neutral-700">{user.name || user.email}</span>
            </span>
          </div>
        </div>

        <div className="flex items-center bg-neutral-100 p-0.5 rounded-xl border border-neutral-200">
          <button
            id="tab-filter-active"
            onClick={() => setBookingFilter('active')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
              bookingFilter === 'active'
                ? 'bg-white text-neutral-900 shadow-2xs'
                : 'text-neutral-500 hover:text-neutral-800'
            }`}
          >
            Active ({activeBookings.length})
          </button>
          <button
            id="tab-filter-past"
            onClick={() => setBookingFilter('past')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
              bookingFilter === 'past'
                ? 'bg-white text-neutral-900 shadow-2xs'
                : 'text-neutral-500 hover:text-neutral-800'
            }`}
          >
            History ({pastBookings.length})
          </button>
        </div>
      </div>

      {/* Main List */}
      <div className="flex-1 overflow-y-auto no-scrollbar p-3 sm:p-4 space-y-4 pb-24">
        {isBookingsLoading ? (
          <div className="py-20 flex flex-col items-center justify-center space-y-3 bg-white rounded-2xl border border-neutral-200 p-6 text-center shadow-2xs">
            <Loader2 className="w-8 h-8 text-neutral-900 animate-spin" />
            <div className="space-y-1">
              <p className="text-xs font-bold text-neutral-900">
                Fetching your bookings from Firestore...
              </p>
              <p className="text-[10px] text-neutral-500 font-mono">
                Collection: 'bookings' • User ID: {user.uid}
              </p>
            </div>
          </div>
        ) : displayedList.length === 0 ? (
          <div className="py-16 text-center bg-white rounded-2xl border border-neutral-200 p-6 space-y-3">
            <div className="w-12 h-12 bg-neutral-100 rounded-full flex items-center justify-center mx-auto text-neutral-400">
              <Calendar className="w-6 h-6" />
            </div>
            <h3 className="text-xs font-bold text-neutral-800">
              No {bookingFilter} bookings found
            </h3>
            <p className="text-xs text-neutral-500 max-w-xs mx-auto">
              Book standard home services with verified professionals & 30-day warranty.
            </p>
            <button
              id="empty-book-now-btn"
              onClick={() => {
                setSelectedCategory('ac-appliance');
                setActiveTab('categories');
              }}
              className="mt-2 text-xs font-bold bg-neutral-900 text-white px-4 py-2 rounded-xl hover:bg-neutral-800 transition-colors"
            >
              Explore Services
            </button>
          </div>
        ) : (
          displayedList.map((booking) => {
            const currentStep = getStatusStepIndex(booking.status);
            const isFinished = booking.status === 'completed';
            const isCancelled = booking.status === 'cancelled';

            return (
              <div
                key={booking.id}
                id={`booking-card-${booking.id}`}
                className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden"
              >
                {/* Booking Header */}
                <div className="p-3.5 bg-neutral-900 text-white flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold font-mono text-emerald-400">
                        {booking.id}
                      </span>
                      <span className="text-[10px] bg-neutral-800 text-neutral-300 px-2 py-0.5 rounded uppercase font-semibold">
                        {booking.paymentStatus === 'paid' ? 'Pre-Paid' : 'Pay After Service'}
                      </span>
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono hidden sm:inline">
                        cloud synced
                      </span>
                      {booking.razorpayPaymentId && (
                        <span className="text-[9px] bg-[#3395ff]/25 text-[#79b9ff] px-1.5 py-0.5 rounded font-mono">
                          RZP TEST
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-neutral-300 mt-0.5 flex items-center gap-1.5">
                      <Clock className="w-3 h-3 text-neutral-400" />
                      <span>
                        {booking.scheduledDate} • {booking.scheduledTimeSlot}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-sm font-black text-white">
                      ₹{booking.totalAmount}
                    </span>
                  </div>
                </div>

                {/* Items in Booking */}
                <div className="p-3.5 border-b border-neutral-100 space-y-2">
                  {booking.items.map((item) => (
                    <div key={item.service.id} className="flex items-center gap-2.5">
                      <img
                        src={item.service.image}
                        alt={item.service.name}
                        className="w-10 h-10 rounded-lg object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1">
                        <div className="text-xs font-bold text-neutral-900 line-clamp-1">
                          {item.service.name}
                        </div>
                        <div className="text-[11px] text-neutral-500">
                          Qty: {item.quantity} • ₹{item.service.price * item.quantity}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Live Status Tracker Stepper (Only for active bookings) */}
                {!isCancelled && (
                  <div className="p-3.5 bg-neutral-50/70 border-b border-neutral-100">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[11px] font-bold text-neutral-900 uppercase tracking-wider flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Live Service Tracker</span>
                      </span>

                      {!isFinished && (
                        <div className="flex items-center gap-1.5">
                          <button
                            id={`open-status-btn-${booking.id}`}
                            onClick={() => setSelectedBookingForStatus(booking)}
                            className="text-[10px] font-bold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 px-2 py-0.5 rounded border border-emerald-300 transition-colors flex items-center gap-1"
                            title="Open Status Screen & Live Map"
                          >
                            <Navigation className="w-3 h-3 text-emerald-700" />
                            <span>Map & Status</span>
                          </button>
                          <button
                            id={`advance-status-btn-${booking.id}`}
                            onClick={() => advanceBookingStatus(booking.id)}
                            className="text-[10px] font-bold text-sky-700 bg-sky-50 hover:bg-sky-100 px-2 py-0.5 rounded border border-sky-200 transition-colors"
                            title="Simulate partner's next step"
                          >
                            Advance ⏩
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Progress Bar and Steps (clickable to open status modal) */}
                    <div
                      className="relative pl-6 space-y-3 cursor-pointer group"
                      onClick={() => !isFinished && setSelectedBookingForStatus(booking)}
                      title="Click to open live status view"
                    >
                      {/* Vertical line */}
                      <div className="absolute left-2.5 top-1.5 bottom-1.5 w-0.5 bg-neutral-200" />

                      {statusSteps.map((step, idx) => {
                        const isDone = currentStep >= idx;
                        const isCurrent = currentStep === idx;

                        return (
                          <div key={idx} className="relative flex items-start gap-2.5 text-left">
                            <span
                              className={`absolute -left-6 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold transition-colors ${
                                isDone
                                  ? 'bg-emerald-600 text-white ring-2 ring-emerald-100'
                                  : 'bg-neutral-200 text-neutral-600'
                              } ${isCurrent ? 'ring-4 ring-emerald-200 animate-pulse' : ''}`}
                            >
                              {isDone ? '✓' : idx + 1}
                            </span>
                            <div>
                              <div
                                className={`text-xs font-bold leading-tight ${
                                  isDone ? 'text-neutral-900' : 'text-neutral-400'
                                }`}
                              >
                                {step.label}
                              </div>
                              <div className="text-[10px] text-neutral-500 leading-tight">
                                {step.desc}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Prominent Button to Open Live Partner Tracking Map Screen */}
                    {!isFinished && (
                      <button
                        type="button"
                        id={`open-tracking-screen-btn-${booking.id}`}
                        onClick={() => setSelectedBookingForStatus(booking)}
                        className="w-full mt-3 py-2.5 px-3 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-extrabold flex items-center justify-between shadow-xs transition-all active:scale-98"
                      >
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                            <Navigation className="w-4 h-4 animate-pulse" />
                          </div>
                          <div className="text-left">
                            <div className="flex items-center gap-1.5">
                              <span className="font-extrabold text-white">Live Partner Tracking Map</span>
                              <span className="text-[9px] bg-emerald-500 text-neutral-950 font-black px-1 rounded uppercase">
                                Live
                              </span>
                            </div>
                            <div className="text-[10px] text-neutral-400 font-normal">
                              View partner route, ETA & OTP verification
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-bold bg-white/10 px-2.5 py-1 rounded-lg">
                          <span>Open</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </div>
                      </button>
                    )}
                  </div>
                )}

                {/* OTP Security Code (QuickServe signature start verification) */}
                {!isFinished && !isCancelled && (
                  <div className="mx-3.5 my-3 p-3 bg-amber-50/80 border border-amber-200 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <KeyRound className="w-4 h-4 text-amber-600" />
                      <div>
                        <div className="text-[10px] font-bold uppercase tracking-wider text-amber-800">
                          Start Service OTP
                        </div>
                        <div className="text-[11px] text-amber-700">
                          Share with professional upon arrival
                        </div>
                      </div>
                    </div>
                    <span className="text-sm font-black font-mono tracking-widest bg-white px-2.5 py-1 rounded border border-amber-300 text-amber-950">
                      {booking.serviceOtp}
                    </span>
                  </div>
                )}

                {/* Assigned Professional Profile (if assigned) */}
                {booking.partner && !isCancelled && (
                  <div className="p-3.5 border-b border-neutral-100 bg-white">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <img
                          src={booking.partner.avatar}
                          alt={booking.partner.name}
                          className="w-11 h-11 rounded-full object-cover ring-2 ring-emerald-500/30"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-neutral-900">
                              {booking.partner.name}
                            </span>
                            <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-1.5 py-0.2 rounded border border-emerald-200">
                              Vaccinated
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-[10px] text-neutral-500 mt-0.5">
                            <span className="flex items-center gap-0.5 font-semibold text-neutral-800">
                              <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                              {booking.partner.rating}
                            </span>
                            <span>•</span>
                            <span>{booking.partner.totalJobs} jobs completed</span>
                          </div>
                        </div>
                      </div>

                      {/* Call & Chat buttons */}
                      <div className="flex items-center gap-1.5">
                        <button
                          id={`call-partner-btn-${booking.id}`}
                          onClick={() => handleContactPartner(booking)}
                          className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 transition-colors border border-emerald-200"
                          title="Call Partner"
                        >
                          <Phone className="w-3.5 h-3.5" />
                        </button>
                        <button
                          id={`chat-partner-btn-${booking.id}`}
                          onClick={() => handleContactPartner(booking)}
                          className="p-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white transition-colors"
                          title="Chat with Partner"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Razorpay Test Gateway Details */}
                {booking.razorpayPaymentId && (
                  <div className="px-3.5 py-2 bg-blue-50/70 border-b border-blue-100 flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-1.5 text-blue-950 font-medium">
                      <CreditCard className="w-3.5 h-3.5 text-[#3395ff]" />
                      <span>Razorpay ID:</span>
                      <span className="font-mono font-bold">{booking.razorpayPaymentId}</span>
                    </div>
                    <span className="text-[9px] bg-blue-100 text-blue-800 font-bold px-1.5 py-0.5 rounded font-mono">
                      TEST AUTH SUCCESS
                    </span>
                  </div>
                )}

                {/* Bottom Actions for Booking */}
                <div className="p-3 bg-neutral-50 flex items-center justify-between text-xs">
                  <span className="text-neutral-500 text-[11px]">
                    Delivering to: {booking.address.label}
                  </span>

                  {!isFinished && !isCancelled ? (
                    <button
                      id={`cancel-booking-btn-${booking.id}`}
                      onClick={() => cancelBooking(booking.id)}
                      className="text-[11px] font-bold text-rose-600 hover:underline"
                    >
                      Cancel Order
                    </button>
                  ) : (
                    <button
                      id={`rebook-btn-${booking.id}`}
                      onClick={() => {
                        setSelectedCategory(booking.items[0]?.service.categoryId || 'ac-appliance');
                        setActiveTab('categories');
                      }}
                      className="text-[11px] font-bold text-neutral-900 hover:underline flex items-center gap-1"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Book Again</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Booking Status & Live Partner Route Tracking Modal */}
      <BookingStatusModal
        booking={activeBookingInModal}
        isOpen={!!selectedBookingForStatus}
        onClose={() => setSelectedBookingForStatus(null)}
      />
    </div>
  );
};
