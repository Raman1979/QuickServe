import React, { useState } from 'react';
import {
  X,
  Trash2,
  Plus,
  Minus,
  Crown,
  MapPin,
  Calendar,
  CreditCard,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  Loader2,
  Lock,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { RazorpayModal, PaymentSuccessData } from './RazorpayModal';

export const CartModal: React.FC = () => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    addToCart,
    removeFromCart,
    cartTotal,
    cartOriginalTotal,
    tipAmount,
    setTipAmount,
    user,
    toggleUCPlus,
    activeAddress,
    setIsLocationModalOpen,
    createBooking,
    setIsAuthModalOpen,
    showNotification,
  } = useApp();

  const [selectedDate, setSelectedDate] = useState<string>('Today');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('04:30 PM - 05:30 PM');
  const [paymentMethod, setPaymentMethod] = useState<string>('UPI (Google Pay)');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [isRazorpayOpen, setIsRazorpayOpen] = useState<boolean>(false);

  if (!isCartOpen) return null;

  const dates = [
    { label: 'Today', sub: 'Instant slot' },
    { label: 'Tomorrow', sub: 'Morning/Eve' },
    { label: 'Sat, 20 Sep', sub: 'Weekend' },
  ];

  const timeSlots = [
    '08:30 AM - 09:30 AM',
    '11:30 AM - 12:30 PM',
    '02:00 PM - 03:00 PM',
    '04:30 PM - 05:30 PM',
    '07:00 PM - 08:00 PM',
  ];

  const plusDiscount = user?.isUCPlusMember ? Math.round(cartTotal * 0.12) : 0;
  const taxesAndFee = cart.length > 0 ? 49 : 0;
  const grandTotal = Math.max(0, cartTotal - plusDiscount + taxesAndFee + tipAmount);

  const handleProceedToPayClick = () => {
    if (!user) {
      setIsAuthModalOpen(true);
      showNotification('Please log in to proceed to checkout & payment');
      return;
    }

    // If user specifically picked cash, they can still book or test online payment
    if (paymentMethod === 'Cash after service') {
      // Prompt option or open Razorpay test mode
      setIsRazorpayOpen(true);
    } else {
      setIsRazorpayOpen(true);
    }
  };

  const handlePaymentSuccess = async (data: PaymentSuccessData) => {
    setIsProcessing(true);
    try {
      await createBooking(
        selectedTimeSlot,
        selectedDate,
        data.paymentMethodUsed || paymentMethod,
        {
          razorpayPaymentId: data.razorpayPaymentId,
          razorpayOrderId: data.razorpayOrderId,
          paymentStatus: 'paid',
        }
      );
      showNotification(`Payment verified via Razorpay! Booking saved to Firestore.`);
    } catch (err) {
      console.error('Booking save error after payment:', err);
      showNotification('Error saving booking to Firestore');
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePaymentFailure = (errorMsg: string) => {
    console.warn('Payment failed state:', errorMsg);
    showNotification('Payment failed! No booking was saved to Firestore.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div
        className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-neutral-200 flex items-center justify-between shrink-0 bg-neutral-900 text-white">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold tracking-tight">Summary & Checkout</h2>
            <span className="text-[11px] bg-neutral-800 text-neutral-300 px-2 py-0.5 rounded-full">
              {cart.reduce((a, b) => a + b.quantity, 0)} items
            </span>
          </div>
          <button
            id="close-cart-modal-btn"
            onClick={() => setIsCartOpen(false)}
            className="p-1 hover:bg-neutral-800 rounded-full text-neutral-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-neutral-900">
          {cart.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto text-neutral-400">
                <Crown className="w-8 h-8" />
              </div>
              <p className="text-sm font-bold text-neutral-800">Your cart is empty</p>
              <p className="text-xs text-neutral-500">
                Explore our top services and add them to schedule a visit!
              </p>
            </div>
          ) : (
            <>
              {/* Item List */}
              <div className="space-y-2.5">
                <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                  Services Added
                </h3>
                {cart.map((item) => (
                  <div
                    key={item.service.id}
                    id={`cart-item-${item.service.id}`}
                    className="flex items-center justify-between p-3 bg-neutral-50 rounded-xl border border-neutral-200/80"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={item.service.image}
                        alt={item.service.name}
                        className="w-11 h-11 rounded-lg object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <div className="text-xs font-bold text-neutral-900 line-clamp-1">
                          {item.service.name}
                        </div>
                        <div className="text-[11px] text-neutral-500">
                          ₹{item.service.price} each
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="bg-white border border-neutral-300 rounded-lg px-2 py-1 flex items-center gap-2 shadow-2xs">
                        <button
                          id={`cart-minus-${item.service.id}`}
                          onClick={() => removeFromCart(item.service.id)}
                          className="hover:text-rose-600 p-0.5 text-neutral-600"
                        >
                          {item.quantity === 1 ? (
                            <Trash2 className="w-3 h-3 text-rose-500" />
                          ) : (
                            <Minus className="w-3 h-3" />
                          )}
                        </button>
                        <span className="text-xs font-bold text-neutral-900">
                          {item.quantity}
                        </span>
                        <button
                          id={`cart-plus-${item.service.id}`}
                          onClick={() => addToCart(item.service)}
                          className="hover:text-emerald-600 p-0.5 text-neutral-600"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <span className="text-xs font-black text-neutral-900 min-w-[50px] text-right">
                        ₹{item.service.price * item.quantity}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* QuickServe Plus Banner */}
              <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500 text-neutral-950 flex items-center justify-center font-bold text-xs shrink-0">
                    ★
                  </div>
                  <div>
                    <div className="text-xs font-bold text-neutral-900">
                      {user?.isUCPlusMember ? 'QuickServe Plus Benefits Applied' : 'Save 12% with QuickServe Plus'}
                    </div>
                    <div className="text-[10px] text-neutral-600">
                      {user?.isUCPlusMember
                        ? `You save ₹${Math.round(cartTotal * 0.12)} on this booking`
                        : 'Get ₹150+ off every order & zero visit fee'}
                    </div>
                  </div>
                </div>

                <button
                  id="cart-toggle-ucplus-btn"
                  onClick={toggleUCPlus}
                  className={`text-[10px] font-bold px-2.5 py-1 rounded-lg border transition-colors ${
                    user?.isUCPlusMember
                      ? 'bg-amber-100 text-amber-900 border-amber-300'
                      : 'bg-amber-500 text-neutral-950 border-amber-600 hover:bg-amber-400'
                  }`}
                >
                  {user?.isUCPlusMember ? 'Enrolled' : 'Join ₹299'}
                </button>
              </div>

              {/* Date & Time Slot Picker */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-neutral-600">
                  <Calendar className="w-3.5 h-3.5 text-neutral-900" />
                  <span>Select Slot</span>
                </div>

                {/* Dates */}
                <div className="grid grid-cols-3 gap-2">
                  {dates.map((d) => (
                    <button
                      key={d.label}
                      id={`date-slot-${d.label}`}
                      onClick={() => setSelectedDate(d.label)}
                      className={`p-2 rounded-xl text-center border transition-all ${
                        selectedDate === d.label
                          ? 'border-neutral-900 bg-neutral-900 text-white shadow-xs'
                          : 'border-neutral-200 bg-white text-neutral-700 hover:border-neutral-400'
                      }`}
                    >
                      <div className="text-xs font-bold">{d.label}</div>
                      <div
                        className={`text-[9px] ${
                          selectedDate === d.label ? 'text-neutral-300' : 'text-neutral-400'
                        }`}
                      >
                        {d.sub}
                      </div>
                    </button>
                  ))}
                </div>

                {/* Time slots */}
                <div className="grid grid-cols-2 gap-1.5 mt-2">
                  {timeSlots.map((slot) => (
                    <button
                      key={slot}
                      id={`time-slot-${slot.replace(/\s+/g, '-')}`}
                      onClick={() => setSelectedTimeSlot(slot)}
                      className={`p-2 text-left rounded-lg text-xs font-semibold border transition-all ${
                        selectedTimeSlot === slot
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-900'
                          : 'border-neutral-200 bg-white text-neutral-700 hover:border-neutral-300'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Service Address */}
              <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200/80 flex items-start justify-between">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-neutral-900">
                        Deliver to: {activeAddress.label}
                      </span>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded">
                        Selected
                      </span>
                    </div>
                    <div className="text-[11px] text-neutral-600 mt-0.5 leading-snug">
                      {activeAddress.flatNo}, {activeAddress.building}, {activeAddress.street}
                    </div>
                  </div>
                </div>

                <button
                  id="change-address-btn"
                  onClick={() => setIsLocationModalOpen(true)}
                  className="text-xs font-bold text-neutral-900 hover:underline shrink-0 ml-2"
                >
                  Change
                </button>
              </div>

              {/* Tip for Partner */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-neutral-700">
                    Add a tip for your professional
                  </span>
                  <span className="text-[10px] text-neutral-400">100% goes to partner</span>
                </div>
                <div className="flex gap-2">
                  {[0, 30, 50, 100].map((amt) => (
                    <button
                      key={amt}
                      id={`tip-btn-${amt}`}
                      onClick={() => setTipAmount(amt)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                        tipAmount === amt
                          ? 'bg-neutral-900 text-white border-neutral-900'
                          : 'bg-white text-neutral-700 border-neutral-200 hover:border-neutral-400'
                      }`}
                    >
                      {amt === 0 ? 'No tip' : `₹${amt}`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Payment Method Selector */}
              <div className="space-y-1.5">
                <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                  Payment Option
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    'UPI (Google Pay)',
                    'Credit / Debit Card',
                    'Paytm / NetBanking',
                    'Cash after service',
                  ].map((method) => (
                    <button
                      key={method}
                      id={`payment-method-${method.replace(/\s+/g, '-')}`}
                      onClick={() => setPaymentMethod(method)}
                      className={`p-2.5 rounded-xl text-left border transition-all ${
                        paymentMethod === method
                          ? 'border-neutral-900 bg-neutral-900 text-white shadow-xs'
                          : 'border-neutral-200 bg-white text-neutral-700 hover:border-neutral-300'
                      }`}
                    >
                      <div className="text-[11px] font-bold truncate">{method}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Bill Details */}
              <div className="bg-neutral-50 rounded-xl p-3 border border-neutral-200/80 space-y-1.5 text-xs">
                <div className="flex justify-between text-neutral-600">
                  <span>Item Total</span>
                  <span>₹{cartTotal}</span>
                </div>

                {plusDiscount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>QuickServe Plus 12% Discount</span>
                    <span>-₹{plusDiscount}</span>
                  </div>
                )}

                <div className="flex justify-between text-neutral-600">
                  <span>Taxes & Partner Safety Fee</span>
                  <span>₹{taxesAndFee}</span>
                </div>

                {tipAmount > 0 && (
                  <div className="flex justify-between text-neutral-600">
                    <span>Partner Tip</span>
                    <span>₹{tipAmount}</span>
                  </div>
                )}

                <div className="pt-2 border-t border-neutral-200 flex justify-between font-black text-sm text-neutral-900">
                  <span>Grand Total</span>
                  <span>₹{grandTotal}</span>
                </div>
              </div>

              {/* Free Cancellation Notice */}
              <div className="text-[10px] text-neutral-500 bg-neutral-100 rounded-lg p-2 text-center">
                🛡️ Free cancellation up to 2 hours before the scheduled time slot.
              </div>
            </>
          )}
        </div>

        {/* Sticky Checkout Button */}
        {cart.length > 0 && (
          <div className="p-4 bg-white border-t border-neutral-200 flex items-center justify-between shrink-0 shadow-lg">
            <div>
              <div className="text-[10px] text-neutral-400 font-medium">To Pay</div>
              <div className="text-base font-black text-neutral-900">₹{grandTotal}</div>
            </div>

            <button
              id="proceed-to-pay-btn"
              disabled={isProcessing}
              onClick={handleProceedToPayClick}
              className="bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs px-6 py-3 rounded-xl shadow-md transition-all flex items-center gap-2 active:scale-95 disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Proceed to Pay</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        )}
      </div>

      {/* Razorpay Test Mode Payment Gateway Modal */}
      <RazorpayModal
        isOpen={isRazorpayOpen}
        onClose={() => setIsRazorpayOpen(false)}
        amount={grandTotal}
        user={user}
        itemCount={cart.reduce((a, b) => a + b.quantity, 0)}
        defaultMethod={paymentMethod}
        onPaymentSuccess={handlePaymentSuccess}
        onPaymentFailure={handlePaymentFailure}
      />
    </div>
  );
};
