import React, { useState } from 'react';
import {
  Sparkles,
  AirVent,
  ShowerHead,
  UserCheck,
  Wrench,
  ShieldCheck,
  Star,
  Plus,
  Minus,
  ArrowRight,
  CheckCircle2,
  Clock,
  Shield,
  Zap,
  Loader2,
  Database,
  RefreshCw,
  Hammer,
  Car,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Category, Service } from '../types';

export const HomeTab: React.FC = () => {
  const {
    categories,
    services,
    isServicesLoading,
    isSeeding,
    seedServicesToFirestore,
    cart,
    addToCart,
    removeFromCart,
    setActiveTab,
    setSelectedCategory,
    setSelectedSubCategory,
    setSelectedServiceForDetail,
    user,
  } = useApp();

  const [activeBannerIndex, setActiveBannerIndex] = useState(0);

  const banners = [
    {
      id: 'banner-ac',
      title: 'Power Jet AC Servicing',
      subtitle: '2X deeper cooling with 30-day leak-proof guarantee',
      tag: 'SUMMER READY',
      bgGradient: 'from-sky-900 to-cyan-950',
      accentColor: 'text-sky-400',
      badgeBg: 'bg-sky-500/20 text-sky-300 border-sky-400/30',
      actionCategory: 'ac-appliance',
      actionSubCategory: 'ac-service',
      image: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=600&q=80',
    },
    {
      id: 'banner-salon',
      title: "Salon Spree at Home",
      subtitle: 'Mono-dose sealed kits & top 1% rated beauticians',
      tag: 'UP TO 40% OFF',
      bgGradient: 'from-rose-950 to-neutral-900',
      accentColor: 'text-rose-400',
      badgeBg: 'bg-rose-500/20 text-rose-300 border-rose-400/30',
      actionCategory: 'women-salon',
      actionSubCategory: 'facial',
      image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=600&q=80',
    },
    {
      id: 'banner-native',
      title: 'Native M2 Smart RO',
      subtitle: 'Needs NO filter change for 2 whole years',
      tag: 'QS FLAGSHIP',
      bgGradient: 'from-purple-950 to-neutral-900',
      accentColor: 'text-purple-400',
      badgeBg: 'bg-purple-500/20 text-purple-300 border-purple-400/30',
      actionCategory: 'native-products',
      actionSubCategory: 'native-ro',
      image: 'https://images.unsplash.com/photo-1548839140-29a749e1bc4e?auto=format&fit=crop&w=600&q=80',
    },
  ];

  const getCategoryIcon = (id: string) => {
    switch (id) {
      case 'ac-appliance':
        return <AirVent className="w-5 h-5 text-sky-600" />;
      case 'women-salon':
        return <Sparkles className="w-5 h-5 text-rose-600" />;
      case 'cleaning-pest':
        return <ShowerHead className="w-5 h-5 text-emerald-600" />;
      case 'men-salon':
        return <UserCheck className="w-5 h-5 text-amber-600" />;
      case 'handyman-construction':
        return <Hammer className="w-5 h-5 text-amber-600" />;
      case 'vehicle-care':
        return <Car className="w-5 h-5 text-indigo-600" />;
      case 'home-help-security':
        return <Shield className="w-5 h-5 text-teal-600" />;
      case 'electrician-plumber':
        return <Wrench className="w-5 h-5 text-blue-600" />;
      case 'native-products':
        return <ShieldCheck className="w-5 h-5 text-purple-600" />;
      default:
        return <Sparkles className="w-5 h-5 text-neutral-600" />;
    }
  };

  const handleCategoryClick = (category: Category) => {
    setSelectedCategory(category.id);
    if (category.subCategories.length > 0) {
      setSelectedSubCategory(category.subCategories[0].id);
    }
    setActiveTab('categories');
  };

  const mostBooked = services.filter((s) => s.isPopular);

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar bg-neutral-50 pb-20">
      {/* Banner Carousel */}
      <div className="p-4 pb-2">
        <div className="relative rounded-2xl overflow-hidden shadow-lg border border-neutral-800">
          <div
            className={`bg-gradient-to-br ${banners[activeBannerIndex].bgGradient} p-4 text-white relative min-h-[145px] flex flex-col justify-between`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="max-w-[65%]">
                <span
                  className={`inline-block text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full border mb-1.5 ${banners[activeBannerIndex].badgeBg}`}
                >
                  {banners[activeBannerIndex].tag}
                </span>
                <h2 className="text-base font-bold leading-tight">
                  {banners[activeBannerIndex].title}
                </h2>
                <p className="text-[11px] text-neutral-300 mt-1 line-clamp-2 leading-relaxed">
                  {banners[activeBannerIndex].subtitle}
                </p>
              </div>

              <div className="w-20 h-20 rounded-xl overflow-hidden ring-2 ring-white/10 shadow-md shrink-0">
                <img
                  src={banners[activeBannerIndex].image}
                  alt={banners[activeBannerIndex].title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/10">
              <button
                id={`banner-explore-btn-${banners[activeBannerIndex].id}`}
                onClick={() => {
                  setSelectedCategory(banners[activeBannerIndex].actionCategory);
                  setSelectedSubCategory(banners[activeBannerIndex].actionSubCategory);
                  setActiveTab('categories');
                }}
                className="text-xs font-bold flex items-center gap-1 text-white hover:underline"
              >
                <span>Book Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              {/* Dots */}
              <div className="flex items-center gap-1">
                {banners.map((_, idx) => (
                  <button
                    key={idx}
                    id={`banner-dot-${idx}`}
                    onClick={() => setActiveBannerIndex(idx)}
                    className={`h-1.5 rounded-full transition-all ${
                      activeBannerIndex === idx ? 'w-4 bg-white' : 'w-1.5 bg-white/40'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Primary Category Grid */}
      <section className="px-4 py-2">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
            Explore Services
          </h2>
          <span className="text-[11px] text-neutral-500">Doorstep in 60 mins</span>
        </div>

        <div className="grid grid-cols-4 gap-2">
          {categories.map((cat) => (
            <button
              key={cat.id}
              id={`cat-card-${cat.id}`}
              onClick={() => handleCategoryClick(cat)}
              className="flex flex-col items-center justify-center p-2.5 bg-white rounded-xl border border-neutral-200/80 shadow-xs hover:border-neutral-400 transition-all text-center group active:scale-95"
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center mb-1.5 transition-transform group-hover:scale-105 ${cat.color}`}
              >
                {getCategoryIcon(cat.id)}
              </div>
              <span className="text-[10px] font-bold text-neutral-800 leading-tight">
                {cat.shortName}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* Quick 15-Minute Handyman Fixes */}
      <section className="px-4 py-3">
        <div className="bg-amber-50/70 border border-amber-200/70 rounded-2xl p-3.5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-600 fill-amber-500" />
              <h3 className="text-xs font-bold text-neutral-900">
                Quick Repairs & Handyman
              </h3>
            </div>
            <span className="text-[10px] font-bold bg-amber-200/60 text-amber-800 px-1.5 py-0.5 rounded">
              Fast Slots
            </span>
          </div>
          <p className="text-[11px] text-neutral-600 mb-3">
            Taps leaking, fan stopped working, or loose switchboard? Fixed in minutes.
          </p>

          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {services
              .filter((s) => s.categoryId === 'handyman-construction' || s.categoryId === 'electrician-plumber')
              .slice(0, 6)
              .map((handyService) => (
                <div
                  key={handyService.id}
                  className="bg-white p-2.5 rounded-xl border border-amber-100 shrink-0 w-44 flex flex-col justify-between"
                >
                  <div>
                    <div className="text-[11px] font-bold text-neutral-900 line-clamp-1">
                      {handyService.name}
                    </div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">
                      ₹{handyService.price} • {handyService.durationMinutes}m
                    </div>
                  </div>
                  <button
                    id={`handy-book-${handyService.id}`}
                    onClick={() => {
                      setSelectedServiceForDetail(handyService);
                    }}
                    className="mt-2 text-[10px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 py-1 px-2 rounded-lg text-center transition-colors border border-emerald-200"
                  >
                    View Details
                  </button>
                </div>
              ))}
          </div>
        </div>
      </section>

      {/* Firestore Database Live Connection Bar */}
      <section className="px-4 py-1">
        <div className="bg-neutral-900 text-white rounded-2xl px-3.5 py-2.5 flex items-center justify-between shadow-xs border border-neutral-800">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <div className="flex items-center gap-1.5 text-xs font-bold">
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              <span>Firestore Collection:</span>
              <span className="text-neutral-400 font-mono text-[11px]">'services'</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-neutral-400 font-semibold hidden sm:inline">
              {services.length} items
            </span>
            <button
              id="sync-services-firestore-btn"
              disabled={isSeeding || isServicesLoading}
              onClick={seedServicesToFirestore}
              className="flex items-center gap-1.5 bg-neutral-800 hover:bg-neutral-700 text-emerald-300 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all border border-neutral-700 active:scale-95 disabled:opacity-50"
              title="Upload servicesData.ts to Firestore"
            >
              <RefreshCw className={`w-3 h-3 ${isSeeding ? 'animate-spin text-emerald-400' : ''}`} />
              <span>{isSeeding ? 'Syncing...' : 'Sync Data'}</span>
            </button>
          </div>
        </div>
      </section>

      {/* Most Booked Services */}
      <section className="px-4 py-2">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
              Most Booked Services
            </h2>
            <p className="text-[11px] text-neutral-500">
              {isServicesLoading
                ? 'Fetching live from Firestore...'
                : `Loaded from Firestore (${services.length} available)`}
            </p>
          </div>
          <button
            id="view-all-categories-btn"
            onClick={() => setActiveTab('categories')}
            className="text-[11px] font-bold text-neutral-900 hover:underline flex items-center gap-0.5"
          >
            <span>All</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {isServicesLoading ? (
          <div className="py-12 flex flex-col items-center justify-center space-y-3 bg-white rounded-2xl border border-neutral-200 shadow-2xs">
            <Loader2 className="w-8 h-8 text-neutral-900 animate-spin" />
            <div className="text-center space-y-1">
              <p className="text-xs font-bold text-neutral-900">
                Fetching services from Firestore...
              </p>
              <p className="text-[10px] text-neutral-500">
                Connecting to collection <span className="font-mono">'services'</span>
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {mostBooked.map((service) => {
              const cartItem = cart.find((item) => item.service.id === service.id);
              const qty = cartItem ? cartItem.quantity : 0;

              return (
                <div
                  key={service.id}
                  id={`service-card-${service.id}`}
                  className="bg-white rounded-2xl p-3.5 border border-neutral-200 shadow-xs flex gap-3.5 items-start hover:shadow-md transition-shadow"
                >
                  <div
                    className="flex-1 cursor-pointer"
                    onClick={() => setSelectedServiceForDetail(service)}
                  >
                    {service.badge && (
                      <span className="inline-block text-[9px] font-bold bg-neutral-900 text-white px-2 py-0.5 rounded uppercase tracking-wider mb-1">
                        {service.badge}
                      </span>
                    )}
                    <h3 className="text-xs font-bold text-neutral-900 leading-snug">
                      {service.name}
                    </h3>

                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex items-center gap-0.5 text-[11px] font-bold text-neutral-800">
                        <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                        <span>{service.rating}</span>
                        <span className="text-neutral-400 font-normal">
                          ({(service.reviewCount / 1000).toFixed(1)}k)
                        </span>
                      </div>
                      <span className="text-neutral-300">•</span>
                      <span className="text-[11px] text-neutral-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {service.durationMinutes} mins
                      </span>
                    </div>

                    <div className="flex items-baseline gap-1.5 mt-2">
                      <span className="text-sm font-extrabold text-neutral-900">
                        ₹{service.price}
                      </span>
                      {service.originalPrice && (
                        <span className="text-xs text-neutral-400 line-through">
                          ₹{service.originalPrice}
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] text-neutral-500 mt-1 line-clamp-1">
                      {service.tagline || service.description}
                    </p>
                  </div>

                  {/* Right Image and Add Button */}
                  <div className="flex flex-col items-center shrink-0 w-24">
                    <div
                      className="w-24 h-20 rounded-xl overflow-hidden cursor-pointer relative shadow-inner"
                      onClick={() => setSelectedServiceForDetail(service)}
                    >
                      <img
                        src={service.image}
                        alt={service.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    <div className="-mt-3.5 z-10">
                      {qty === 0 ? (
                        <button
                          id={`add-service-btn-${service.id}`}
                          onClick={() => addToCart(service)}
                          className="bg-white border border-emerald-600 text-emerald-700 font-bold text-xs px-4 py-1 rounded-lg shadow-md hover:bg-emerald-50 transition-colors uppercase tracking-wider"
                        >
                          Add
                        </button>
                      ) : (
                        <div className="bg-emerald-600 text-white font-bold text-xs px-2 py-1 rounded-lg shadow-md flex items-center gap-2">
                          <button
                            id={`decrease-service-btn-${service.id}`}
                            onClick={() => removeFromCart(service.id)}
                            className="hover:opacity-80 p-0.5"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span>{qty}</span>
                          <button
                            id={`increase-service-btn-${service.id}`}
                            onClick={() => addToCart(service)}
                            className="hover:opacity-80 p-0.5"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* QuickServe Plus Card */}
      <section className="px-4 py-3">
        <div className="bg-gradient-to-r from-neutral-900 via-neutral-800 to-amber-950 text-white rounded-2xl p-4 shadow-md border border-neutral-700">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-amber-500/20 text-amber-400 flex items-center justify-center font-black text-xs">
                ★
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
                QuickServe Plus Membership
              </span>
            </div>
            {user?.isUCPlusMember && (
              <span className="text-[10px] font-bold bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-400/30">
                Active Member
              </span>
            )}
          </div>

          <h3 className="text-sm font-bold text-white mb-1">
            Save 10% to 15% on every booking
          </h3>
          <p className="text-[11px] text-neutral-300 leading-relaxed mb-3">
            Plus zero visit fees, free cancellation, and top 1% certified professionals.
          </p>

          <button
            id="home-uc-plus-btn"
            onClick={() => setActiveTab('uc-plus')}
            className="w-full py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs transition-colors shadow-sm flex items-center justify-center gap-1.5"
          >
            <span>{user?.isUCPlusMember ? 'View Plus Benefits' : 'Join QuickServe Plus for ₹299'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </section>

      {/* QuickServe Assurance */}
      <section className="px-4 py-3">
        <h3 className="text-xs font-bold text-neutral-900 uppercase tracking-wider mb-2.5">
          QuickServe Assurance
        </h3>

        <div className="grid grid-cols-2 gap-2">
          <div className="bg-white p-3 rounded-xl border border-neutral-200/80 flex items-start gap-2">
            <Shield className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <div className="text-[11px] font-bold text-neutral-900">30-Day Warranty</div>
              <div className="text-[10px] text-neutral-500 leading-tight mt-0.5">
                Free rework if unsatisfied
              </div>
            </div>
          </div>

          <div className="bg-white p-3 rounded-xl border border-neutral-200/80 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
            <div>
              <div className="text-[11px] font-bold text-neutral-900">Verified Pros</div>
              <div className="text-[10px] text-neutral-500 leading-tight mt-0.5">
                Background-checked partners
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
