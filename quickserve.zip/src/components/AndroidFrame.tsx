import React, { useState, useEffect } from 'react';
import { Smartphone, Monitor, Wifi, BatteryMedium, Signal } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface AndroidFrameProps {
  children: React.ReactNode;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children }) => {
  const { isDeviceFrame, setIsDeviceFrame } = useApp();
  const [currentTime, setCurrentTime] = useState('09:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col items-center justify-start antialiased selection:bg-neutral-800">
      {/* Top Desktop Controls Bar */}
      <header className="w-full bg-neutral-900 border-b border-neutral-800 px-4 py-2.5 flex items-center justify-between z-30 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-neutral-950 border border-neutral-700 flex items-center justify-center font-black text-xs text-white tracking-wider">
            QS
          </div>
          <div>
            <span className="font-semibold text-sm text-white flex items-center gap-1.5">
              QuickServe
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.5 rounded border border-emerald-500/30">
                Android
              </span>
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <button
            id="toggle-view-mode-btn"
            onClick={() => setIsDeviceFrame(!isDeviceFrame)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors border border-neutral-700 font-medium"
          >
            {isDeviceFrame ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-neutral-400" />
                <span>Responsive View</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-neutral-400" />
                <span>Android Phone Frame</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main viewport area */}
      <main className="w-full flex-1 flex items-center justify-center p-0 sm:p-4 overflow-hidden">
        {isDeviceFrame ? (
          /* Android Frame View */
          <div className="relative w-full max-w-[425px] h-[100vh] sm:h-[880px] max-h-[100vh] sm:max-h-[92vh] bg-black sm:rounded-[48px] sm:ring-[10px] sm:ring-neutral-800 sm:shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] flex flex-col overflow-hidden border border-neutral-800">
            {/* Camera Punchhole on Android */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 z-50 pointer-events-none hidden sm:flex items-center justify-center">
              <div className="w-3.5 h-3.5 rounded-full bg-black ring-1 ring-neutral-800 flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-neutral-900" />
              </div>
            </div>

            {/* Android Status Bar */}
            <div className="w-full h-7 bg-neutral-900/90 backdrop-blur-md px-5 flex items-center justify-between text-[11px] font-medium text-neutral-300 z-40 shrink-0 select-none">
              <span>{currentTime}</span>
              <div className="flex items-center gap-1.5 text-neutral-400">
                <Signal className="w-3 h-3" />
                <span className="text-[10px] font-bold text-neutral-300">5G</span>
                <Wifi className="w-3 h-3" />
                <div className="flex items-center gap-0.5">
                  <span className="text-[10px]">88%</span>
                  <BatteryMedium className="w-3.5 h-3.5 text-emerald-400" />
                </div>
              </div>
            </div>

            {/* Inner App Content Screen */}
            <div className="flex-1 w-full overflow-hidden flex flex-col bg-white text-neutral-900 relative">
              {children}
            </div>

            {/* Android Navigation Gesture Pill */}
            <div className="w-full h-4 bg-neutral-900 flex items-center justify-center shrink-0 z-40">
              <div className="w-32 h-1 bg-neutral-600 rounded-full" />
            </div>
          </div>
        ) : (
          /* Full Responsive View */
          <div className="w-full max-w-2xl h-[calc(100vh-50px)] bg-white text-neutral-900 rounded-xl shadow-2xl flex flex-col overflow-hidden border border-neutral-800">
            {children}
          </div>
        )}
      </main>
    </div>
  );
};
