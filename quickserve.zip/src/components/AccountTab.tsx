import React, { useState } from 'react';
import {
  User,
  Wallet,
  MapPin,
  HelpCircle,
  Shield,
  Share2,
  LogOut,
  ChevronRight,
  Plus,
  Crown,
  Phone,
  Mail,
  CheckCircle2,
  LogIn,
  Sparkles,
  ShieldCheck,
  Database,
  RefreshCw,
  Loader2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AccountTab: React.FC = () => {
  const {
    user,
    logout,
    setIsAuthModalOpen,
    setAuthModalMode,
    addresses,
    activeAddress,
    setActiveAddress,
    addAddress,
    showNotification,
    setActiveTab,
    services,
    isServicesLoading,
    isSeeding,
    seedServicesToFirestore,
  } = useApp();

  const [showAddAddressModal, setShowAddAddressModal] = useState(false);
  const [flatNo, setFlatNo] = useState('');
  const [building, setBuilding] = useState('');
  const [street, setStreet] = useState('');
  const [label, setLabel] = useState<'Home' | 'Work' | 'Other'>('Home');

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!flatNo || !building || !street) {
      showNotification('Please fill in all address fields');
      return;
    }
    addAddress({
      label,
      flatNo,
      building,
      street,
      city: 'Bengaluru',
      pincode: '560038',
      isDefault: false,
    });
    setFlatNo('');
    setBuilding('');
    setStreet('');
    setShowAddAddressModal(false);
  };

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar bg-neutral-100 p-4 space-y-4 pb-24 text-neutral-900">
      {/* Profile or Login/Register Card */}
      {user ? (
        <div className="bg-white rounded-3xl p-4 border border-neutral-200 shadow-xs flex items-center justify-between animate-in fade-in duration-200">
          <div className="flex items-center gap-3">
            <div className="w-13 h-13 rounded-2xl bg-neutral-900 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-extrabold text-neutral-900 leading-tight">
                  {user.name}
                </h2>
                {user.isUCPlusMember && (
                  <span className="text-[9px] font-black bg-amber-400 text-neutral-950 px-1.5 py-0.2 rounded-md">
                    PLUS
                  </span>
                )}
              </div>
              <div className="text-[11px] text-neutral-500 mt-0.5 flex items-center gap-1">
                <Phone className="w-3 h-3" />
                <span>{user.phone || '+91 98200 81234'}</span>
              </div>
              {user.email && (
                <div className="text-[11px] text-neutral-400 flex items-center gap-1">
                  <Mail className="w-3 h-3" />
                  <span>{user.email}</span>
                </div>
              )}
            </div>
          </div>

          <button
            id="account-view-plus-btn"
            onClick={() => setActiveTab('uc-plus')}
            className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold hover:bg-amber-100 transition-colors"
          >
            <Crown className="w-4 h-4 text-amber-600" />
          </button>
        </div>
      ) : (
        /* Unauthenticated Login / Register Banner */
        <div className="bg-white rounded-3xl p-5 border border-neutral-200 shadow-xs space-y-3 animate-in fade-in duration-200">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-neutral-100 text-neutral-400 flex items-center justify-center">
              <User className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold text-neutral-900 leading-tight">
                Welcome to QuickServe
              </h2>
              <p className="text-[11px] text-neutral-500 mt-0.5">
                Sign in to manage bookings, addresses, and discounts
              </p>
            </div>
          </div>

          <div className="flex gap-2 pt-1">
            <button
              id="account-login-btn"
              onClick={() => {
                setAuthModalMode('login');
                setIsAuthModalOpen(true);
              }}
              className="flex-1 py-2.5 bg-neutral-950 hover:bg-neutral-800 text-white rounded-xl font-bold text-xs shadow-sm transition-all flex items-center justify-center gap-1.5"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Login / Register</span>
            </button>

            <button
              id="account-phone-login-btn"
              onClick={() => {
                setAuthModalMode('phone');
                setIsAuthModalOpen(true);
              }}
              className="py-2.5 px-3 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-xl font-bold text-xs border border-neutral-200 transition-colors flex items-center gap-1"
            >
              <Phone className="w-3.5 h-3.5 text-neutral-600" />
              <span>OTP</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5 text-[10px] text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
            <Sparkles className="w-3 h-3 text-emerald-600 shrink-0" />
            <span>New users get ₹100 welcome bonus on signup!</span>
          </div>
        </div>
      )}

      {/* QuickServe Wallet Card */}
      <div className="bg-neutral-900 text-white rounded-2xl p-4 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] text-neutral-400 font-semibold uppercase tracking-wider">
              QuickServe Cash
            </div>
            <div className="text-base font-black text-white">
              ₹{user ? user.walletBalance : 0}
            </div>
          </div>
        </div>

        <button
          id="add-money-wallet-btn"
          onClick={() => {
            if (!user) {
              setIsAuthModalOpen(true);
              showNotification('Please login to use QuickServe Cash wallet');
              return;
            }
            showNotification('₹200 promotional cash added!');
          }}
          className="text-xs font-bold bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-xl transition-colors border border-white/10"
        >
          + Add Money
        </button>
      </div>

      {/* Saved Addresses Section */}
      <div className="bg-white rounded-2xl p-4 border border-neutral-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-600" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900">
              Saved Addresses
            </h3>
          </div>

          <button
            id="open-add-address-btn"
            onClick={() => {
              if (!user) {
                setIsAuthModalOpen(true);
                showNotification('Please login to save addresses');
                return;
              }
              setShowAddAddressModal(true);
            }}
            className="text-xs font-bold text-emerald-700 hover:underline flex items-center gap-1"
          >
            <Plus className="w-3 h-3" />
            <span>Add New</span>
          </button>
        </div>

        <div className="space-y-2">
          {addresses.map((addr) => {
            const isSelected = activeAddress.id === addr.id;
            return (
              <div
                key={addr.id}
                id={`saved-addr-${addr.id}`}
                onClick={() => setActiveAddress(addr)}
                className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                  isSelected
                    ? 'border-neutral-900 bg-neutral-50 ring-1 ring-neutral-900'
                    : 'border-neutral-200 hover:border-neutral-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-neutral-900">
                    {addr.label}
                  </span>
                  {isSelected && (
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      Default
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-neutral-600 mt-1 leading-snug">
                  {addr.flatNo}, {addr.building}, {addr.street}, {addr.city} - {addr.pincode}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Address Mini Form Modal */}
      {showAddAddressModal && (
        <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-xs font-bold text-neutral-900">Add New Address</h4>
            <button
              id="close-add-address-form-btn"
              onClick={() => setShowAddAddressModal(false)}
              className="text-xs text-neutral-500 font-bold hover:text-neutral-900"
            >
              Cancel
            </button>
          </div>

          <form onSubmit={handleSaveAddress} className="space-y-2.5">
            <div className="flex gap-2">
              {(['Home', 'Work', 'Other'] as const).map((l) => (
                <button
                  type="button"
                  key={l}
                  id={`label-${l.toLowerCase()}`}
                  onClick={() => setLabel(l)}
                  className={`flex-1 py-1 rounded-lg text-xs font-bold border transition-colors ${
                    label === l
                      ? 'bg-neutral-900 text-white border-neutral-900'
                      : 'bg-white text-neutral-700 border-neutral-200'
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>

            <input
              id="addr-flat-input"
              type="text"
              placeholder="Flat / House / Door No."
              value={flatNo}
              onChange={(e) => setFlatNo(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-neutral-200 bg-white focus:outline-none focus:border-neutral-900"
              required
            />
            <input
              id="addr-building-input"
              type="text"
              placeholder="Apartment / Building name"
              value={building}
              onChange={(e) => setBuilding(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-neutral-200 bg-white focus:outline-none focus:border-neutral-900"
              required
            />
            <input
              id="addr-street-input"
              type="text"
              placeholder="Street / Area / Locality"
              value={street}
              onChange={(e) => setStreet(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-neutral-200 bg-white focus:outline-none focus:border-neutral-900"
              required
            />

            <button
              type="submit"
              id="save-address-submit-btn"
              className="w-full py-2.5 bg-neutral-900 text-white rounded-xl font-bold text-xs hover:bg-neutral-800 transition-colors"
            >
              Save Address
            </button>
          </form>
        </div>
      )}

      {/* Firestore Database & Cloud Catalog */}
      <div className="bg-neutral-900 text-white rounded-2xl p-4 border border-neutral-800 shadow-md">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>Firestore Database</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <div className="text-[10px] text-neutral-400 font-mono">
                Collection: 'services' • {services.length} items
              </div>
            </div>
          </div>

          <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
            Live
          </span>
        </div>

        <p className="text-[11px] text-neutral-300 leading-relaxed mb-3">
          All service catalog entries are stored and queried in real time directly from your Firebase Firestore cloud database.
        </p>

        <button
          id="account-sync-firestore-btn"
          disabled={isSeeding || isServicesLoading}
          onClick={seedServicesToFirestore}
          className="w-full py-2.5 px-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-emerald-300 font-bold text-xs transition-colors border border-neutral-700 flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50 shadow-xs"
        >
          {isSeeding ? (
            <>
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Uploading servicesData.ts to Firestore...</span>
            </>
          ) : (
            <>
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Upload / Re-sync servicesData.ts to Firestore</span>
            </>
          )}
        </button>
      </div>

      {/* Navigation Options List */}
      <div className="bg-white rounded-2xl border border-neutral-200 divide-y divide-neutral-100 overflow-hidden shadow-xs">
        <button
          id="help-support-btn"
          onClick={() => showNotification('Connecting to 24x7 QuickServe Live Support')}
          className="w-full p-3.5 flex items-center justify-between text-left hover:bg-neutral-50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <HelpCircle className="w-4 h-4 text-neutral-600" />
            <span className="text-xs font-bold text-neutral-800">
              Help Center & Safety
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-400" />
        </button>

        <button
          id="share-app-btn"
          onClick={() => {
            navigator.clipboard?.writeText(window.location.href);
            showNotification('App link copied to clipboard!');
          }}
          className="w-full p-3.5 flex items-center justify-between text-left hover:bg-neutral-50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <Share2 className="w-4 h-4 text-neutral-600" />
            <span className="text-xs font-bold text-neutral-800">
              Refer Friends (Earn ₹100 QuickServe Cash)
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-400" />
        </button>

        <button
          id="insurance-cover-btn"
          onClick={() => showNotification('QuickServe provides up to ₹10,000 property damage cover on every job.')}
          className="w-full p-3.5 flex items-center justify-between text-left hover:bg-neutral-50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <Shield className="w-4 h-4 text-neutral-600" />
            <span className="text-xs font-bold text-neutral-800">
              QuickServe Insurance & Protection
            </span>
          </div>
          <ChevronRight className="w-4 h-4 text-neutral-400" />
        </button>

        {/* Logout Option if Logged In */}
        {user && (
          <button
            id="account-logout-btn"
            onClick={logout}
            className="w-full p-3.5 flex items-center justify-between text-left hover:bg-rose-50 text-rose-600 transition-colors"
          >
            <div className="flex items-center gap-3">
              <LogOut className="w-4 h-4 text-rose-600" />
              <span className="text-xs font-bold">
                Log Out
              </span>
            </div>
            <ChevronRight className="w-4 h-4 text-rose-400" />
          </button>
        )}
      </div>

      {/* App Version Info */}
      <div className="text-center text-[10px] text-neutral-400 pt-2 space-y-1">
        <div className="flex items-center justify-center gap-1">
          <ShieldCheck className="w-3 h-3 text-emerald-500" />
          <span>Secured with Google Firebase Authentication</span>
        </div>
        <div>QuickServe Android App v8.14.2</div>
      </div>
    </div>
  );
};
