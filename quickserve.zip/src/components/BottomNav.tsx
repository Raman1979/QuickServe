import React from 'react';
import {
  Home,
  LayoutGrid,
  CalendarCheck,
  Crown,
  User,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface TabItem {
  id: 'home' | 'categories' | 'bookings' | 'uc-plus' | 'account';
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
  isSpecial?: boolean;
}

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, bookings } = useApp();

  const activeBookingsCount = bookings.filter(
    (b) => b.status !== 'completed' && b.status !== 'cancelled'
  ).length;

  const tabs: TabItem[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'categories', label: 'Categories', icon: LayoutGrid },
    { id: 'bookings', label: 'Bookings', icon: CalendarCheck, badge: activeBookingsCount },
    { id: 'uc-plus', label: 'QuickServe Plus', icon: Crown, isSpecial: true },
    { id: 'account', label: 'Account', icon: User },
  ];

  return (
    <nav className="bg-white border-t border-neutral-200 px-3 py-1.5 flex items-center justify-around shrink-0 z-30 shadow-[0_-4px_12px_rgba(0,0,0,0.04)]">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;

        return (
          <button
            key={tab.id}
            id={`nav-tab-${tab.id}`}
            onClick={() => setActiveTab(tab.id)}
            className="flex flex-col items-center justify-center py-1 px-2 relative min-w-[56px] transition-transform active:scale-95"
          >
            <div className="relative">
              <Icon
                className={`w-5 h-5 transition-colors ${
                  isActive
                    ? tab.isSpecial
                      ? 'text-amber-500'
                      : 'text-neutral-900'
                    : 'text-neutral-400 hover:text-neutral-600'
                }`}
              />
              {Boolean(tab.badge && tab.badge > 0) && (
                <span className="absolute -top-1 -right-2 bg-emerald-500 text-white font-bold text-[9px] w-3.5 h-3.5 rounded-full flex items-center justify-center ring-1 ring-white">
                  {tab.badge}
                </span>
              )}
            </div>
            <span
              className={`text-[10px] font-semibold mt-0.5 tracking-tight ${
                isActive
                  ? tab.isSpecial
                    ? 'text-amber-600 font-bold'
                    : 'text-neutral-900 font-bold'
                  : 'text-neutral-500'
              }`}
            >
              {tab.label}
            </span>
            {isActive && (
              <span
                className={`w-1 h-1 rounded-full mt-0.5 ${
                  tab.isSpecial ? 'bg-amber-500' : 'bg-neutral-900'
                }`}
              />
            )}
          </button>
        );
      })}
    </nav>
  );
};
