import React, { useState } from 'react';
import {
  X,
  Mail,
  Lock,
  User as UserIcon,
  Phone,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    setIsAuthModalOpen,
    authModalMode,
    setAuthModalMode,
    loginWithEmail,
    signupWithEmail,
    loginWithPhoneOtp,
    loginDemoUser,
  } = useApp();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [phoneOtp, setPhoneOtp] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [otpTimer, setOtpTimer] = useState(30);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isAuthModalOpen) return null;

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await loginWithEmail(email, password);
      setIsAuthModalOpen(false);
      setEmail('');
      setPassword('');
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password') {
        setError('Invalid email or password. If you are new, please Sign Up.');
      } else if (err.code === 'auth/invalid-email') {
        setError('Please enter a valid email address.');
      } else {
        setError(err.message || 'Failed to sign in. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEmailSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!name.trim()) {
      setError('Please enter your full name.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    setLoading(true);
    try {
      await signupWithEmail(email, password, name, phone || '+91 98200 81234');
      setIsAuthModalOpen(false);
      setEmail('');
      setPassword('');
      setName('');
      setPhone('');
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/email-already-in-use') {
        setError('This email is already registered. Please login instead.');
      } else {
        setError(err.message || 'Failed to create account. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.length < 10) {
      setError('Please enter a valid 10-digit mobile number.');
      return;
    }
    setError(null);
    setIsOtpSent(true);
    setOtpTimer(30);
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!phoneOtp || phoneOtp.length < 4) {
      setError('Please enter the 4-digit verification code.');
      return;
    }
    setLoading(true);
    try {
      await loginWithPhoneOtp(phone, phoneOtp);
      setIsAuthModalOpen(false);
      setPhone('');
      setPhoneOtp('');
      setIsOtpSent(false);
    } catch (err: any) {
      setError(err.message || 'Invalid OTP code.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoSignIn = async () => {
    setLoading(true);
    try {
      await loginDemoUser();
      setIsAuthModalOpen(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-xs p-0 sm:p-4">
      <div
        className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 bg-neutral-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-white text-neutral-950 flex items-center justify-center font-black text-xs">
              QS
            </div>
            <div>
              <h2 className="text-sm font-extrabold tracking-tight">
                {authModalMode === 'login'
                  ? 'Welcome Back'
                  : authModalMode === 'signup'
                  ? 'Create Your Account'
                  : 'Instant Mobile Login'}
              </h2>
              <p className="text-[10px] text-neutral-400">
                QuickServe Firebase Authentication
              </p>
            </div>
          </div>

          <button
            id="close-auth-modal-btn"
            onClick={() => setIsAuthModalOpen(false)}
            className="p-1 hover:bg-neutral-800 rounded-full text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="bg-neutral-100 p-1.5 flex gap-1 border-b border-neutral-200 shrink-0">
          <button
            id="auth-tab-login"
            onClick={() => {
              setAuthModalMode('login');
              setError(null);
            }}
            className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
              authModalMode === 'login'
                ? 'bg-white text-neutral-900 shadow-2xs'
                : 'text-neutral-500 hover:text-neutral-800'
            }`}
          >
            Email Login
          </button>

          <button
            id="auth-tab-signup"
            onClick={() => {
              setAuthModalMode('signup');
              setError(null);
            }}
            className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
              authModalMode === 'signup'
                ? 'bg-white text-neutral-900 shadow-2xs'
                : 'text-neutral-500 hover:text-neutral-800'
            }`}
          >
            Sign Up
          </button>

          <button
            id="auth-tab-phone"
            onClick={() => {
              setAuthModalMode('phone');
              setError(null);
            }}
            className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
              authModalMode === 'phone'
                ? 'bg-white text-neutral-900 shadow-2xs'
                : 'text-neutral-500 hover:text-neutral-800'
            }`}
          >
            Phone OTP
          </button>
        </div>

        {/* Form Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-neutral-900">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-xs text-rose-800 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Mode 1: Email Password Login */}
          {authModalMode === 'login' && (
            <form onSubmit={handleEmailLogin} className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider block mb-1">
                  Email Address
                </label>
                <div className="flex items-center bg-neutral-100 rounded-xl px-3 py-2.5 border border-neutral-200 focus-within:border-neutral-900 focus-within:bg-white transition-colors">
                  <Mail className="w-4 h-4 text-neutral-400 mr-2 shrink-0" />
                  <input
                    id="login-email-input"
                    type="email"
                    required
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full text-xs font-medium bg-transparent focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider block mb-1">
                  Password
                </label>
                <div className="flex items-center bg-neutral-100 rounded-xl px-3 py-2.5 border border-neutral-200 focus-within:border-neutral-900 focus-within:bg-white transition-colors">
                  <Lock className="w-4 h-4 text-neutral-400 mr-2 shrink-0" />
                  <input
                    id="login-password-input"
                    type="password"
                    required
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full text-xs font-medium bg-transparent focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                id="submit-email-login-btn"
                disabled={loading}
                className="w-full py-3 bg-neutral-950 hover:bg-neutral-800 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? 'Authenticating...' : 'Sign In with Email'}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* Mode 2: Sign Up */}
          {authModalMode === 'signup' && (
            <form onSubmit={handleEmailSignup} className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider block mb-1">
                  Full Name
                </label>
                <div className="flex items-center bg-neutral-100 rounded-xl px-3 py-2.5 border border-neutral-200 focus-within:border-neutral-900 focus-within:bg-white transition-colors">
                  <UserIcon className="w-4 h-4 text-neutral-400 mr-2 shrink-0" />
                  <input
                    id="signup-name-input"
                    type="text"
                    required
                    placeholder="e.g. Priya Sharma"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full text-xs font-medium bg-transparent focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider block mb-1">
                  Email Address
                </label>
                <div className="flex items-center bg-neutral-100 rounded-xl px-3 py-2.5 border border-neutral-200 focus-within:border-neutral-900 focus-within:bg-white transition-colors">
                  <Mail className="w-4 h-4 text-neutral-400 mr-2 shrink-0" />
                  <input
                    id="signup-email-input"
                    type="email"
                    required
                    placeholder="priya.sharma@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full text-xs font-medium bg-transparent focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider block mb-1">
                  Mobile Number (Optional)
                </label>
                <div className="flex items-center bg-neutral-100 rounded-xl px-3 py-2.5 border border-neutral-200 focus-within:border-neutral-900 focus-within:bg-white transition-colors">
                  <Phone className="w-4 h-4 text-neutral-400 mr-2 shrink-0" />
                  <input
                    id="signup-phone-input"
                    type="tel"
                    placeholder="+91 98200 81234"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full text-xs font-medium bg-transparent focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider block mb-1">
                  Password (min. 6 characters)
                </label>
                <div className="flex items-center bg-neutral-100 rounded-xl px-3 py-2.5 border border-neutral-200 focus-within:border-neutral-900 focus-within:bg-white transition-colors">
                  <Lock className="w-4 h-4 text-neutral-400 mr-2 shrink-0" />
                  <input
                    id="signup-password-input"
                    type="password"
                    required
                    placeholder="Create a strong password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full text-xs font-medium bg-transparent focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                id="submit-email-signup-btn"
                disabled={loading}
                className="w-full py-3 bg-neutral-950 hover:bg-neutral-800 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? 'Creating Profile...' : 'Register & Claim ₹100 Cash'}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* Mode 3: Phone OTP Login */}
          {authModalMode === 'phone' && (
            <div className="space-y-3">
              {!isOtpSent ? (
                <form onSubmit={handleSendOtp} className="space-y-3">
                  <div>
                    <label className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider block mb-1">
                      Mobile Number
                    </label>
                    <div className="flex items-center bg-neutral-100 rounded-xl px-3 py-2.5 border border-neutral-200 focus-within:border-neutral-900 focus-within:bg-white transition-colors">
                      <span className="text-xs font-bold text-neutral-700 mr-2 border-r border-neutral-300 pr-2">
                        🇮🇳 +91
                      </span>
                      <input
                        id="otp-phone-input"
                        type="tel"
                        maxLength={10}
                        required
                        placeholder="Enter 10-digit number"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                        className="w-full text-xs font-medium bg-transparent focus:outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    id="send-otp-btn"
                    className="w-full py-3 bg-neutral-950 hover:bg-neutral-800 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <span>Get Verification Code</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtp} className="space-y-3">
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold">OTP sent to +91 {phone}</div>
                      <div className="text-[11px] text-emerald-700 mt-0.5">
                        Demo code: <span className="font-mono font-bold bg-white px-1.5 py-0.2 rounded border border-emerald-300">4892</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider block mb-1">
                      Enter 4-Digit OTP
                    </label>
                    <div className="flex items-center bg-neutral-100 rounded-xl px-3 py-2.5 border border-neutral-200 focus-within:border-neutral-900 focus-within:bg-white transition-colors">
                      <KeyRound className="w-4 h-4 text-neutral-400 mr-2 shrink-0" />
                      <input
                        id="otp-code-input"
                        type="text"
                        maxLength={6}
                        required
                        placeholder="e.g. 4892"
                        value={phoneOtp}
                        onChange={(e) => setPhoneOtp(e.target.value)}
                        className="w-full text-xs font-mono font-bold tracking-widest bg-transparent focus:outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    id="verify-otp-btn"
                    disabled={loading}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {loading ? 'Verifying OTP...' : 'Verify OTP & Log In'}
                  </button>

                  <button
                    type="button"
                    id="change-phone-btn"
                    onClick={() => setIsOtpSent(false)}
                    className="w-full text-center text-xs text-neutral-500 font-semibold hover:text-neutral-900"
                  >
                    Change Phone Number
                  </button>
                </form>
              )}
            </div>
          )}

          {/* Quick 1-Click Demo Login */}
          <div className="pt-2 border-t border-neutral-200">
            <button
              type="button"
              id="instant-demo-login-btn"
              onClick={handleDemoSignIn}
              disabled={loading}
              className="w-full py-2.5 px-3 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 font-bold text-xs flex items-center justify-between transition-colors shadow-2xs"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <div className="text-left">
                  <div className="leading-tight">Quick Demo Account (Aarav Mehta)</div>
                  <div className="text-[10px] text-amber-700 font-normal">
                    Instant 1-click test sign-in with pre-loaded QuickServe Plus
                  </div>
                </div>
              </div>
              <span className="text-[10px] bg-amber-200/80 text-amber-950 font-black px-2 py-1 rounded-md">
                Fast Test
              </span>
            </button>
          </div>

          {/* Security Guarantee */}
          <div className="flex items-center justify-center gap-1.5 text-[10px] text-neutral-400 text-center">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Encrypted with Google Firebase Authentication</span>
          </div>
        </div>
      </div>
    </div>
  );
};
