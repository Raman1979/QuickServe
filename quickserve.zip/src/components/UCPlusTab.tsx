import React, { useState } from 'react';
import {
  Crown,
  CheckCircle2,
  Sparkles,
  Shield,
  Zap,
  TrendingUp,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const UCPlusTab: React.FC = () => {
  const { user, toggleUCPlus, setActiveTab, setSelectedCategory } = useApp();
  const [selectedPlan, setSelectedPlan] = useState<'12m' | '6m'>('12m');

  return (
    <div className="flex-1 overflow-y-auto no-scrollbar bg-neutral-950 text-white p-4 space-y-4 pb-24">
      {/* Top Banner */}
      <div className="relative rounded-3xl p-5 overflow-hidden bg-gradient-to-br from-amber-500/20 via-neutral-900 to-black border border-amber-500/30 shadow-2xl">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-amber-400 font-extrabold text-xs tracking-widest uppercase mb-1">
              <Crown className="w-4 h-4" />
              <span>QuickServe Plus Club</span>
            </div>
            <h1 className="text-xl font-black text-white leading-tight">
              {user?.isUCPlusMember ? 'You are a QuickServe VIP Plus Member' : 'Unlock Extra 15% Off with QuickServe Plus'}
            </h1>
          </div>

          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 font-bold shrink-0">
            ★
          </div>
        </div>

        {/* Savings counter if member */}
        {user?.isUCPlusMember ? (
          <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
            <div>
              <div className="text-[10px] text-neutral-400 uppercase font-semibold">
                Your Lifetime Savings
              </div>
              <div className="text-lg font-black text-amber-400">
                ₹{(user?.totalSavings || 0).toLocaleString()}
              </div>
            </div>

            <div className="text-right">
              <div className="text-[10px] text-neutral-400 uppercase font-semibold">
                Valid Through
              </div>
              <div className="text-xs font-bold text-white">
                {user?.plusExpiryDate || 'Dec 2026'}
              </div>
            </div>
          </div>
        ) : (
          <p className="text-xs text-neutral-300 mt-2 leading-relaxed">
            Join 2.5 million+ smart Indian homeowners saving average ₹4,200 yearly on salon, cleaning, and AC repairs.
          </p>
        )}
      </div>

      {/* 4 Core Perks */}
      <div className="space-y-2.5">
        <h2 className="text-xs font-bold uppercase tracking-wider text-amber-300">
          Exclusive Membership Perks
        </h2>

        <div className="grid grid-cols-2 gap-2.5">
          <div className="bg-neutral-900/90 border border-neutral-800 p-3 rounded-2xl">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-2">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div className="text-xs font-bold text-white">Extra 10-15% Off</div>
            <div className="text-[10px] text-neutral-400 leading-tight mt-0.5">
              Instant auto-discount on all services
            </div>
          </div>

          <div className="bg-neutral-900/90 border border-neutral-800 p-3 rounded-2xl">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-2">
              <Zap className="w-4 h-4" />
            </div>
            <div className="text-xs font-bold text-white">Zero Visit Fees</div>
            <div className="text-[10px] text-neutral-400 leading-tight mt-0.5">
              No convenience charge ever
            </div>
          </div>

          <div className="bg-neutral-900/90 border border-neutral-800 p-3 rounded-2xl">
            <div className="w-8 h-8 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center mb-2">
              <Crown className="w-4 h-4" />
            </div>
            <div className="text-xs font-bold text-white">Top 1% Pros Only</div>
            <div className="text-[10px] text-neutral-400 leading-tight mt-0.5">
              Priority allocation of 4.85+ star partners
            </div>
          </div>

          <div className="bg-neutral-900/90 border border-neutral-800 p-3 rounded-2xl">
            <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center mb-2">
              <Clock className="w-4 h-4" />
            </div>
            <div className="text-xs font-bold text-white">Free Cancellation</div>
            <div className="text-[10px] text-neutral-400 leading-tight mt-0.5">
              Reschedule or cancel without penalty
            </div>
          </div>
        </div>
      </div>

      {/* Plan selection if not active */}
      {!user.isUCPlusMember && (
        <div className="space-y-2.5">
          <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
            Select Your Membership Pass
          </h2>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              id="plan-12m-btn"
              onClick={() => setSelectedPlan('12m')}
              className={`p-3 rounded-2xl border text-left relative transition-all ${
                selectedPlan === '12m'
                  ? 'border-amber-400 bg-amber-500/10 shadow-lg'
                  : 'border-neutral-800 bg-neutral-900'
              }`}
            >
              <span className="absolute -top-2 right-2 bg-amber-500 text-neutral-950 font-black text-[9px] px-1.5 py-0.5 rounded">
                BEST VALUE
              </span>
              <div className="text-xs font-bold text-white">12 Months Pass</div>
              <div className="text-base font-black text-amber-400 mt-1">₹299</div>
              <div className="text-[9px] text-neutral-400 mt-0.5">₹25 / month</div>
            </button>

            <button
              id="plan-6m-btn"
              onClick={() => setSelectedPlan('6m')}
              className={`p-3 rounded-2xl border text-left transition-all ${
                selectedPlan === '6m'
                  ? 'border-amber-400 bg-amber-500/10 shadow-lg'
                  : 'border-neutral-800 bg-neutral-900'
              }`}
            >
              <div className="text-xs font-bold text-white">6 Months Pass</div>
              <div className="text-base font-black text-amber-400 mt-1">₹199</div>
              <div className="text-[9px] text-neutral-400 mt-0.5">₹33 / month</div>
            </button>
          </div>
        </div>
      )}

      {/* Action Button */}
      <div className="pt-2">
        <button
          id="uc-plus-action-btn"
          onClick={toggleUCPlus}
          className={`w-full py-3.5 rounded-2xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl transition-transform active:scale-95 ${
            user?.isUCPlusMember
              ? 'bg-neutral-800 hover:bg-neutral-700 text-white border border-neutral-700'
              : 'bg-amber-400 hover:bg-amber-300 text-neutral-950 shadow-amber-500/20'
          }`}
        >
          <Crown className="w-4 h-4" />
          <span>{user?.isUCPlusMember ? 'Manage Membership' : 'Get QuickServe Plus for ₹299'}</span>
        </button>
      </div>

      {/* Quick service book link */}
      <div className="p-3 bg-neutral-900 rounded-2xl border border-neutral-800 flex items-center justify-between text-xs">
        <span className="text-neutral-300 text-[11px]">
          Ready to save on your next service?
        </span>
        <button
          id="uc-plus-book-now-btn"
          onClick={() => {
            setSelectedCategory('ac-appliance');
            setActiveTab('categories');
          }}
          className="font-bold text-amber-400 hover:underline flex items-center gap-1"
        >
          <span>Book Now</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
