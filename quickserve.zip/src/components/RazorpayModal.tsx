import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  CreditCard,
  Smartphone,
  Building2,
  Lock,
  ArrowRight,
  RefreshCw,
  Loader2,
  Sparkles,
  Info,
} from 'lucide-react';
import { UserProfile } from '../types';

export interface PaymentSuccessData {
  razorpayPaymentId: string;
  razorpayOrderId: string;
  paymentMethodUsed: string;
}

interface RazorpayModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  user: UserProfile | null;
  itemCount: number;
  defaultMethod?: string;
  onPaymentSuccess: (data: PaymentSuccessData) => Promise<void> | void;
  onPaymentFailure: (errorMsg: string) => void;
}

type PaymentTab = 'upi' | 'card' | 'netbanking';
type GatewayStatus = 'idle' | 'processing' | 'success' | 'failure';

export const RazorpayModal: React.FC<RazorpayModalProps> = ({
  isOpen,
  onClose,
  amount,
  user,
  itemCount,
  defaultMethod = 'UPI (Google Pay)',
  onPaymentSuccess,
  onPaymentFailure,
}) => {
  const [activeTab, setActiveTab] = useState<PaymentTab>(() => {
    if (defaultMethod.toLowerCase().includes('card')) return 'card';
    if (defaultMethod.toLowerCase().includes('netbanking')) return 'netbanking';
    return 'upi';
  });

  const [status, setStatus] = useState<GatewayStatus>('idle');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [generatedPaymentId, setGeneratedPaymentId] = useState<string>('');
  const [generatedOrderId, setGeneratedOrderId] = useState<string>('');
  const [isSavingToFirestore, setIsSavingToFirestore] = useState<boolean>(false);

  // Form states
  const [upiId, setUpiId] = useState<string>('success@razorpay');
  const [selectedUpiApp, setSelectedUpiApp] = useState<string>('Google Pay');
  const [cardNumber, setCardNumber] = useState<string>('4111 1111 1111 1111');
  const [cardExpiry, setCardExpiry] = useState<string>('12/28');
  const [cardCvv, setCardCvv] = useState<string>('123');
  const [cardHolder, setCardHolder] = useState<string>(user?.name || 'Aarav Mehta');
  const [selectedBank, setSelectedBank] = useState<string>('HDFC Bank');

  // Reset when opening
  useEffect(() => {
    if (isOpen) {
      setStatus('idle');
      setErrorMessage('');
      setIsSavingToFirestore(false);
      const randOrder = `order_${Math.random().toString(36).substring(2, 10)}`;
      setGeneratedOrderId(randOrder);
      if (user?.name) {
        setCardHolder(user.name);
      }
    }
  }, [isOpen, user?.name]);

  if (!isOpen) return null;

  const generatePaymentId = () => `pay_${Math.random().toString(36).substring(2, 12).toUpperCase()}`;

  const triggerProcessing = (shouldSucceed: boolean, customError?: string) => {
    setStatus('processing');
    setErrorMessage('');

    setTimeout(async () => {
      if (shouldSucceed) {
        const paymentId = generatePaymentId();
        setGeneratedPaymentId(paymentId);
        setStatus('success');
        setIsSavingToFirestore(true);

        const methodLabel =
          activeTab === 'upi'
            ? `UPI (${selectedUpiApp} - ${upiId})`
            : activeTab === 'card'
            ? `Card (Ending in ${cardNumber.slice(-4) || '1111'})`
            : `Netbanking (${selectedBank})`;

        try {
          await onPaymentSuccess({
            razorpayPaymentId: paymentId,
            razorpayOrderId: generatedOrderId,
            paymentMethodUsed: methodLabel,
          });
        } catch (err) {
          console.error('Firestore saving error:', err);
        } finally {
          setIsSavingToFirestore(false);
        }
      } else {
        const failureReason =
          customError ||
          'Payment declined by bank issuer. Insufficient test balance or invalid OTP. (Razorpay Error: BAD_REQUEST_ERROR)';
        setStatus('failure');
        setErrorMessage(failureReason);
        onPaymentFailure(failureReason);
      }
    }, 1600);
  };

  const handlePayNow = () => {
    // Check if user entered failure test values
    if (activeTab === 'upi' && upiId.toLowerCase().includes('fail')) {
      triggerProcessing(false, 'Transaction failed: UPI PIN validation failed on customer device');
      return;
    }
    if (activeTab === 'card' && cardNumber.replace(/\s+/g, '').endsWith('0002')) {
      triggerProcessing(false, 'Transaction failed: Card reported stolen/declined by issuing bank');
      return;
    }

    triggerProcessing(true);
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 sm:p-4">
      <div
        id="razorpay-test-modal"
        className="w-full max-w-md bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col animate-in zoom-in-95 duration-150 border border-neutral-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Razorpay Header */}
        <div className="bg-[#0c2340] text-white p-4 shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-[#3395ff] text-white font-black text-sm flex items-center justify-center shadow-inner tracking-tighter">
                R
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-sm tracking-tight text-white">Razorpay</span>
                  <span className="text-[9px] font-black uppercase tracking-wider bg-amber-400 text-neutral-950 px-1.5 py-0.5 rounded">
                    TEST MODE
                  </span>
                </div>
                <div className="text-[10px] text-neutral-400">Secured Checkout Gateway</div>
              </div>
            </div>

            {status !== 'processing' && (
              <button
                id="close-razorpay-modal-btn"
                onClick={onClose}
                className="p-1.5 text-neutral-400 hover:text-white rounded-full hover:bg-white/10 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Merchant & Amount Banner */}
          <div className="mt-3.5 pt-3 border-t border-white/10 flex items-center justify-between">
            <div>
              <div className="text-[11px] text-neutral-300 font-medium">Merchant</div>
              <div className="text-xs font-bold text-white flex items-center gap-1">
                <span>QuickServe Services</span>
                <span className="text-[10px] text-neutral-400">({itemCount} items)</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-neutral-300 uppercase font-medium">Amount to Pay</div>
              <div className="text-lg font-black text-emerald-400 tracking-tight">₹{amount}</div>
            </div>
          </div>
        </div>

        {/* Modal Body Based on Gateway Status */}
        {status === 'processing' && (
          <div className="p-8 flex flex-col items-center justify-center text-center space-y-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center text-[#3395ff]">
                <Loader2 className="w-8 h-8 animate-spin" />
              </div>
              <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-[#3395ff]"></span>
              </span>
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-neutral-900">
                Contacting Payment Gateway...
              </h3>
              <p className="text-xs text-neutral-500 max-w-xs leading-relaxed">
                Verifying dummy credentials with Razorpay test server. Please do not close or refresh this window.
              </p>
            </div>
            <div className="inline-flex items-center gap-1.5 bg-neutral-100 text-[10px] text-neutral-600 font-mono px-2.5 py-1 rounded-full">
              <Lock className="w-3 h-3 text-neutral-400" />
              <span>256-bit SSL Test Sandbox</span>
            </div>
          </div>
        )}

        {status === 'success' && (
          <div className="p-6 flex flex-col items-center justify-center text-center space-y-4 animate-in fade-in duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shadow-xs">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-black uppercase tracking-wider bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                Payment Authorized
              </span>
              <h3 className="text-base font-extrabold text-neutral-900 mt-1">
                Payment of ₹{amount} Successful!
              </h3>
              <p className="text-xs text-neutral-500">
                Transaction confirmed in Razorpay Test Gateway.
              </p>
            </div>

            <div className="w-full bg-neutral-50 border border-neutral-200 rounded-2xl p-3 text-left space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-neutral-500">Razorpay Payment ID</span>
                <span className="font-mono font-bold text-neutral-900">{generatedPaymentId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Razorpay Order ID</span>
                <span className="font-mono text-neutral-700">{generatedOrderId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Firestore Cloud Status</span>
                <span className="font-semibold text-emerald-700 flex items-center gap-1">
                  {isSavingToFirestore ? (
                    <>
                      <Loader2 className="w-3 h-3 animate-spin" />
                      <span>Writing to 'bookings'...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>Saved in Firestore Database</span>
                    </>
                  )}
                </span>
              </div>
            </div>

            <button
              id="razorpay-success-done-btn"
              disabled={isSavingToFirestore}
              onClick={onClose}
              className="w-full py-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs shadow-md transition-colors flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
            >
              <span>View Booking in Tracker</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {status === 'failure' && (
          <div className="p-6 flex flex-col items-center justify-center text-center space-y-4 animate-in fade-in duration-200">
            <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center shadow-xs">
              <AlertTriangle className="w-9 h-9" />
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-black uppercase tracking-wider bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full">
                Payment Failed
              </span>
              <h3 className="text-base font-extrabold text-neutral-900 mt-1">
                Transaction Could Not Be Completed
              </h3>
              <p className="text-xs text-neutral-600 max-w-xs leading-relaxed">
                {errorMessage || 'The payment was declined. No money was deducted.'}
              </p>
            </div>

            <div className="w-full bg-rose-50/70 border border-rose-200 rounded-xl p-3 text-left text-[11px] text-rose-900 space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                <span>Firestore Safety Guarantee:</span>
              </div>
              <p className="text-rose-700">
                Because payment failed, this booking was <strong>NOT saved</strong> to the Firestore <code className="font-mono bg-rose-100 px-1 py-0.5 rounded">bookings</code> collection. Your cart remains ready for retry.
              </p>
            </div>

            <div className="w-full flex gap-2 pt-1">
              <button
                id="razorpay-retry-btn"
                onClick={() => setStatus('idle')}
                className="flex-1 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs shadow-xs transition-colors flex items-center justify-center gap-1.5 active:scale-95"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Try Again</span>
              </button>
              <button
                id="razorpay-cancel-btn"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-bold text-xs transition-colors"
              >
                Return to Cart
              </button>
            </div>
          </div>
        )}

        {status === 'idle' && (
          <div className="flex-1 overflow-y-auto no-scrollbar flex flex-col">
            {/* Tabs */}
            <div className="grid grid-cols-3 border-b border-neutral-200 bg-neutral-50/70 p-1">
              <button
                id="tab-razorpay-upi"
                onClick={() => setActiveTab('upi')}
                className={`py-2 px-1 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  activeTab === 'upi'
                    ? 'bg-white text-[#0c2340] shadow-2xs'
                    : 'text-neutral-500 hover:text-neutral-900'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5 text-[#3395ff]" />
                <span>UPI / QR</span>
              </button>

              <button
                id="tab-razorpay-card"
                onClick={() => setActiveTab('card')}
                className={`py-2 px-1 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  activeTab === 'card'
                    ? 'bg-white text-[#0c2340] shadow-2xs'
                    : 'text-neutral-500 hover:text-neutral-900'
                }`}
              >
                <CreditCard className="w-3.5 h-3.5 text-[#3395ff]" />
                <span>Cards</span>
              </button>

              <button
                id="tab-razorpay-netbanking"
                onClick={() => setActiveTab('netbanking')}
                className={`py-2 px-1 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  activeTab === 'netbanking'
                    ? 'bg-white text-[#0c2340] shadow-2xs'
                    : 'text-neutral-500 hover:text-neutral-900'
                }`}
              >
                <Building2 className="w-3.5 h-3.5 text-[#3395ff]" />
                <span>NetBanking</span>
              </button>
            </div>

            {/* Tab Contents */}
            <div className="p-4 space-y-4">
              {/* UPI Tab */}
              {activeTab === 'upi' && (
                <div className="space-y-3.5">
                  <div>
                    <div className="text-[11px] font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                      Fast Pay via UPI Apps
                    </div>
                    <div className="grid grid-cols-4 gap-2">
                      {['Google Pay', 'PhonePe', 'Paytm', 'BHIM'].map((app) => (
                        <button
                          key={app}
                          id={`upi-app-${app.toLowerCase().replace(/\s+/g, '-')}`}
                          type="button"
                          onClick={() => {
                            setSelectedUpiApp(app);
                            setUpiId(
                              app === 'Google Pay'
                                ? 'user@okaxis'
                                : app === 'PhonePe'
                                ? 'user@ybl'
                                : 'user@paytm'
                            );
                          }}
                          className={`p-2 rounded-xl border text-center transition-all ${
                            selectedUpiApp === app
                              ? 'border-[#3395ff] bg-blue-50/60 text-[#0c2340] font-bold shadow-2xs'
                              : 'border-neutral-200 bg-white text-neutral-600 hover:border-neutral-300'
                          }`}
                        >
                          <div className="text-[10px] font-bold leading-tight">{app}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-neutral-700 flex items-center justify-between">
                      <span>UPI ID / VPA</span>
                      <span className="text-[10px] text-neutral-400 font-normal">
                        Type <code className="text-rose-600 font-mono">failure@razorpay</code> to test decline
                      </span>
                    </label>
                    <input
                      id="razorpay-upi-id-input"
                      type="text"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      placeholder="e.g. yourname@okhdfcbank"
                      className="w-full px-3 py-2 text-xs border border-neutral-300 rounded-xl focus:outline-hidden focus:border-[#3395ff] focus:ring-1 focus:ring-[#3395ff]"
                    />
                  </div>

                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => setUpiId('success@razorpay')}
                      className="text-[10px] px-2 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-md font-medium hover:bg-emerald-100"
                    >
                      Fill Success VPA
                    </button>
                    <button
                      type="button"
                      onClick={() => setUpiId('failure@razorpay')}
                      className="text-[10px] px-2 py-1 bg-rose-50 text-rose-700 border border-rose-200 rounded-md font-medium hover:bg-rose-100"
                    >
                      Fill Failure VPA
                    </button>
                  </div>
                </div>
              )}

              {/* Cards Tab */}
              {activeTab === 'card' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-neutral-700">Card Information</span>
                    <div className="flex gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          setCardNumber('4111 1111 1111 1111');
                          setCardExpiry('12/28');
                          setCardCvv('123');
                        }}
                        className="text-[9px] px-1.5 py-0.5 bg-neutral-100 hover:bg-neutral-200 rounded text-neutral-700 font-mono font-bold"
                      >
                        Success Card
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setCardNumber('4000 0000 0000 0002');
                          setCardExpiry('12/28');
                          setCardCvv('123');
                        }}
                        className="text-[9px] px-1.5 py-0.5 bg-rose-100 hover:bg-rose-200 rounded text-rose-800 font-mono font-bold"
                      >
                        Decline Card
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-neutral-500 uppercase">Card Number</label>
                    <div className="relative">
                      <input
                        id="razorpay-card-number-input"
                        type="text"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        placeholder="4111 1111 1111 1111"
                        className="w-full px-3 py-2 text-xs border border-neutral-300 rounded-xl focus:outline-hidden focus:border-[#3395ff] font-mono"
                      />
                      <CreditCard className="w-4 h-4 text-neutral-400 absolute right-3 top-2.5" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-neutral-500 uppercase">Expiry (MM/YY)</label>
                      <input
                        id="razorpay-card-expiry-input"
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="12/28"
                        className="w-full px-3 py-2 text-xs border border-neutral-300 rounded-xl focus:outline-hidden focus:border-[#3395ff] font-mono text-center"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-neutral-500 uppercase">CVV</label>
                      <input
                        id="razorpay-card-cvv-input"
                        type="password"
                        maxLength={4}
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                        placeholder="123"
                        className="w-full px-3 py-2 text-xs border border-neutral-300 rounded-xl focus:outline-hidden focus:border-[#3395ff] font-mono text-center"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-neutral-500 uppercase">Cardholder Name</label>
                    <input
                      id="razorpay-cardholder-input"
                      type="text"
                      value={cardHolder}
                      onChange={(e) => setCardHolder(e.target.value)}
                      placeholder="Name on card"
                      className="w-full px-3 py-2 text-xs border border-neutral-300 rounded-xl focus:outline-hidden focus:border-[#3395ff]"
                    />
                  </div>
                </div>
              )}

              {/* Netbanking Tab */}
              {activeTab === 'netbanking' && (
                <div className="space-y-3">
                  <div className="text-[11px] font-bold text-neutral-700">Popular Banks</div>
                  <div className="grid grid-cols-2 gap-2">
                    {['HDFC Bank', 'ICICI Bank', 'State Bank of India', 'Axis Bank', 'Kotak Mahindra'].map(
                      (bank) => (
                        <button
                          key={bank}
                          id={`bank-btn-${bank.toLowerCase().replace(/\s+/g, '-')}`}
                          type="button"
                          onClick={() => setSelectedBank(bank)}
                          className={`p-2 rounded-xl text-left border text-xs font-semibold transition-all ${
                            selectedBank === bank
                              ? 'border-[#3395ff] bg-blue-50/60 text-[#0c2340] font-bold shadow-2xs'
                              : 'border-neutral-200 bg-white text-neutral-700 hover:border-neutral-300'
                          }`}
                        >
                          {bank}
                        </button>
                      )
                    )}
                  </div>
                </div>
              )}

              {/* Action Button: Pay Now */}
              <button
                id="razorpay-pay-now-btn"
                type="button"
                onClick={handlePayNow}
                className="w-full py-3 rounded-xl bg-[#3395ff] hover:bg-[#2084f0] text-white font-extrabold text-xs tracking-wide shadow-md transition-all flex items-center justify-center gap-2 active:scale-98"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Pay ₹{amount}</span>
              </button>

              {/* Test Sandbox Simulation Shortcuts */}
              <div className="pt-2 border-t border-neutral-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-500" />
                    <span>Razorpay Test Sandbox Triggers</span>
                  </span>
                  <span className="text-[9px] text-neutral-400">1-click test</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    id="simulate-success-btn"
                    type="button"
                    onClick={() => triggerProcessing(true)}
                    className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] shadow-xs flex items-center justify-center gap-1.5 transition-colors active:scale-95"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Simulate Success</span>
                  </button>

                  <button
                    id="simulate-failure-btn"
                    type="button"
                    onClick={() =>
                      triggerProcessing(
                        false,
                        'Test Simulator: Transaction failed due to 3D-Secure timeout / bank refusal'
                      )
                    }
                    className="py-2 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] shadow-xs flex items-center justify-center gap-1.5 transition-colors active:scale-95"
                  >
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Simulate Failure</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Footer Trust Badge */}
            <div className="p-3 bg-neutral-50 border-t border-neutral-200 text-center flex items-center justify-center gap-1.5 text-[10px] text-neutral-500">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Razorpay Test Gateway v2 • No actual charge will be made</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
