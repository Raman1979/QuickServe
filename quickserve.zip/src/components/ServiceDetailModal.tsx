import React from 'react';
import {
  X,
  Star,
  Clock,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  Plus,
  Minus,
  Check,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ServiceDetailModal: React.FC = () => {
  const {
    selectedServiceForDetail,
    setSelectedServiceForDetail,
    cart,
    addToCart,
    removeFromCart,
    setIsCartOpen,
  } = useApp();

  if (!selectedServiceForDetail) return null;

  const service = selectedServiceForDetail;
  const cartItem = cart.find((item) => item.service.id === service.id);
  const qty = cartItem ? cartItem.quantity : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div
        className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with image */}
        <div className="relative h-48 sm:h-52 w-full bg-neutral-900 shrink-0">
          <img
            src={service.image}
            alt={service.name}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

          {/* Close button */}
          <button
            id="close-service-detail-modal-btn"
            onClick={() => setSelectedServiceForDetail(null)}
            className="absolute top-3 right-3 p-1.5 bg-black/60 hover:bg-black/80 text-white rounded-full transition-colors z-10"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Badge & Title */}
          <div className="absolute bottom-3 left-4 right-4 text-white">
            {service.badge && (
              <span className="inline-block text-[9px] font-extrabold uppercase tracking-wider px-2 py-0.5 bg-amber-500 text-neutral-950 rounded mb-1">
                {service.badge}
              </span>
            )}
            <h2 className="text-base font-bold leading-tight drop-shadow-sm">
              {service.name}
            </h2>
          </div>
        </div>

        {/* Scrollable details content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-neutral-900">
          {/* Quick stats row */}
          <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1 text-xs font-bold text-neutral-900">
                <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                <span>{service.rating}</span>
                <span className="text-neutral-400 font-normal">
                  ({service.reviewCount.toLocaleString()} reviews)
                </span>
              </div>
              <span className="text-neutral-300">•</span>
              <div className="flex items-center gap-1 text-xs text-neutral-600 font-medium">
                <Clock className="w-3.5 h-3.5" />
                <span>{service.durationMinutes} mins</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-base font-black text-neutral-900">
                ₹{service.price}
              </span>
              {service.originalPrice && (
                <span className="text-xs text-neutral-400 line-through ml-1.5">
                  ₹{service.originalPrice}
                </span>
              )}
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-1">
              About This Service
            </h3>
            <p className="text-xs text-neutral-700 leading-relaxed">
              {service.description}
            </p>
          </div>

          {/* What's Included */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 mb-2 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>What is Included</span>
            </h3>
            <div className="bg-emerald-50/50 border border-emerald-100 rounded-xl p-3 space-y-2">
              {service.inclusions.map((inc, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-neutral-800 leading-snug">
                  <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{inc}</span>
                </div>
              ))}
            </div>
          </div>

          {/* What's Excluded */}
          {service.exclusions && service.exclusions.length > 0 && (
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 mb-2 flex items-center gap-1.5">
                <XCircle className="w-3.5 h-3.5 text-rose-500" />
                <span>Please Note (Excluded)</span>
              </h3>
              <div className="bg-neutral-50 border border-neutral-200/70 rounded-xl p-3 space-y-2">
                {service.exclusions.map((exc, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-neutral-600 leading-snug">
                    <span className="w-1.5 h-1.5 rounded-full bg-neutral-400 shrink-0 mt-1.5" />
                    <span>{exc}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* QuickServe Safety Standards */}
          <div className="bg-neutral-900 text-white rounded-xl p-3 flex items-center gap-3">
            <ShieldCheck className="w-7 h-7 text-emerald-400 shrink-0" />
            <div>
              <div className="text-xs font-bold text-white">QuickServe Promise</div>
              <div className="text-[11px] text-neutral-300 leading-tight mt-0.5">
                Police-verified professionals • Sealed single-use kit • 30-day rework warranty
              </div>
            </div>
          </div>
        </div>

        {/* Sticky bottom CTA bar */}
        <div className="p-3.5 bg-white border-t border-neutral-200 flex items-center justify-between shrink-0 shadow-lg">
          <div>
            <div className="text-[10px] text-neutral-400 font-medium">Total Price</div>
            <div className="text-base font-black text-neutral-900">
              ₹{service.price * (qty > 0 ? qty : 1)}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {qty === 0 ? (
              <button
                id="modal-add-to-cart-btn"
                onClick={() => addToCart(service)}
                className="bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow-md transition-colors uppercase tracking-wider"
              >
                Add to Cart
              </button>
            ) : (
              <div className="flex items-center gap-3">
                <div className="bg-neutral-100 border border-neutral-300 rounded-xl px-2 py-1.5 flex items-center gap-3">
                  <button
                    id="modal-qty-minus-btn"
                    onClick={() => removeFromCart(service.id)}
                    className="p-1 hover:bg-white rounded-lg text-neutral-700"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-xs font-bold text-neutral-900">{qty}</span>
                  <button
                    id="modal-qty-plus-btn"
                    onClick={() => addToCart(service)}
                    className="p-1 hover:bg-white rounded-lg text-neutral-700"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  id="modal-view-cart-btn"
                  onClick={() => {
                    setSelectedServiceForDetail(null);
                    setIsCartOpen(true);
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md transition-colors"
                >
                  View Cart
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
