import React, { useState } from 'react';
import {
  MapPin,
  ChevronDown,
  Search,
  ShoppingCart,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Header: React.FC = () => {
  const {
    selectedLocation,
    setIsLocationModalOpen,
    cartCount,
    setIsCartOpen,
    searchQuery,
    setSearchQuery,
    services,
    setSelectedServiceForDetail,
    user,
    setIsAuthModalOpen,
    setActiveTab,
  } = useApp();

  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const searchResults = searchQuery.trim()
    ? services.filter(
        (s) =>
          s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.tagline?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <div className="bg-neutral-900 text-white pt-3 pb-3 px-4 shrink-0 shadow-md relative z-30">
      {/* Top Location & Cart Row */}
      <div className="flex items-center justify-between gap-2 mb-2.5">
        <button
          id="header-location-selector"
          onClick={() => setIsLocationModalOpen(true)}
          className="flex items-center gap-1.5 text-left group max-w-[70%]"
        >
          <div className="w-7 h-7 rounded-full bg-neutral-800 flex items-center justify-center shrink-0 text-white">
            <MapPin className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="overflow-hidden">
            <div className="flex items-center gap-1 text-[11px] text-neutral-400 leading-tight">
              <span>Location</span>
              <ChevronDown className="w-3 h-3 text-neutral-400 group-hover:text-white transition-colors" />
            </div>
            <div className="text-xs font-bold text-white truncate leading-tight">
              {selectedLocation.area}, {selectedLocation.city}
            </div>
          </div>
        </button>

        {/* User Status & Cart */}
        <div className="flex items-center gap-2">
          {user ? (
            <button
              id="header-user-profile-btn"
              onClick={() => setActiveTab('account')}
              className="flex items-center gap-1.5 py-1 px-2 rounded-full bg-neutral-800 hover:bg-neutral-700 transition-colors text-white text-xs font-bold"
              title="View Account"
            >
              <div className="w-5 h-5 rounded-full bg-emerald-500 text-neutral-950 flex items-center justify-center font-bold text-[10px]">
                {user.name ? user.name.charAt(0).toUpperCase() : 'Q'}
              </div>
              <span className="max-w-[70px] truncate text-[11px] font-semibold">
                {user.name.split(' ')[0]}
              </span>
            </button>
          ) : (
            <button
              id="header-login-btn"
              onClick={() => setIsAuthModalOpen(true)}
              className="py-1 px-2.5 rounded-full bg-neutral-800 hover:bg-neutral-700 transition-colors text-white text-[11px] font-bold border border-neutral-700"
            >
              Login
            </button>
          )}

          {/* Cart Icon & Counter */}
          <button
            id="header-cart-btn"
            onClick={() => setIsCartOpen(true)}
            className="relative p-2 rounded-full bg-neutral-800 hover:bg-neutral-700 transition-colors text-white"
            aria-label="View Cart"
          >
            <ShoppingCart className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-emerald-500 text-neutral-950 font-black text-[10px] w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-neutral-900 animate-pulse">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Search Input Bar */}
      <div className="relative">
        <div className="flex items-center bg-white text-neutral-900 rounded-xl px-3 py-2 shadow-inner border border-neutral-200">
          <Search className="w-4 h-4 text-neutral-400 shrink-0 mr-2" />
          <input
            id="global-service-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setTimeout(() => setIsSearchFocused(false), 250)}
            placeholder="Search QuickServe for 'AC service', 'Salon', 'Cleaning'..."
            className="w-full text-xs font-medium bg-transparent focus:outline-none placeholder:text-neutral-400"
          />
          {searchQuery && (
            <button
              id="clear-search-btn"
              onClick={() => setSearchQuery('')}
              className="p-1 hover:bg-neutral-100 rounded-full text-neutral-400 hover:text-neutral-700"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Instant Search Results Dropdown */}
        {isSearchFocused && searchQuery.trim() && (
          <div className="absolute top-full left-0 right-0 mt-1.5 bg-white text-neutral-900 rounded-xl shadow-2xl border border-neutral-200 max-h-72 overflow-y-auto z-50 p-2">
            <div className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider px-2 py-1">
              Matching Services ({searchResults.length})
            </div>
            {searchResults.length === 0 ? (
              <div className="py-4 text-center text-xs text-neutral-500">
                No services found for "{searchQuery}"
              </div>
            ) : (
              searchResults.map((item) => (
                <button
                  key={item.id}
                  id={`search-result-${item.id}`}
                  onClick={() => {
                    setSelectedServiceForDetail(item);
                    setSearchQuery('');
                  }}
                  className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-neutral-50 transition-colors text-left"
                >
                  <div className="flex items-center gap-2.5">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-10 h-10 rounded-lg object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="text-xs font-semibold text-neutral-900 line-clamp-1">
                        {item.name}
                      </div>
                      <div className="text-[11px] text-neutral-500">
                        ₹{item.price} • {item.durationMinutes} mins
                      </div>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    View
                  </span>
                </button>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
