import React, { useState } from 'react';
import { X, MapPin, Navigation, Search, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CITIES_LIST } from '../data/servicesData';

export const LocationPickerModal: React.FC = () => {
  const {
    isLocationModalOpen,
    setIsLocationModalOpen,
    selectedLocation,
    setSelectedLocation,
    showNotification,
  } = useApp();

  const [searchFilter, setSearchFilter] = useState('');
  const [selectedCity, setSelectedCity] = useState(selectedLocation.city);

  if (!isLocationModalOpen) return null;

  const currentCityObj = CITIES_LIST.find((c) => c.name === selectedCity) || CITIES_LIST[0];

  const filteredAreas = currentCityObj.areas.filter((area) =>
    area.toLowerCase().includes(searchFilter.toLowerCase())
  );

  const handleSelectArea = (city: string, area: string) => {
    setSelectedLocation({ city, area });
    setIsLocationModalOpen(false);
    showNotification(`Location updated to ${area}, ${city}`);
  };

  const handleUseCurrentGPS = () => {
    setSelectedLocation({ city: 'Bengaluru', area: 'Indiranagar' });
    setIsLocationModalOpen(false);
    showNotification('GPS Location locked: Indiranagar, Bengaluru');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div
        className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl max-h-[85vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-neutral-200 flex items-center justify-between shrink-0 bg-neutral-900 text-white">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-400" />
            <h2 className="text-sm font-bold">Select Service Location</h2>
          </div>
          <button
            id="close-location-modal-btn"
            onClick={() => setIsLocationModalOpen(false)}
            className="p-1 hover:bg-neutral-800 rounded-full text-neutral-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4 overflow-y-auto">
          {/* GPS Auto-detect */}
          <button
            id="gps-locate-btn"
            onClick={handleUseCurrentGPS}
            className="w-full p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 font-bold text-xs flex items-center gap-2.5 hover:bg-emerald-100 transition-colors shadow-2xs"
          >
            <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
              <Navigation className="w-3.5 h-3.5" />
            </div>
            <div className="text-left flex-1">
              <div className="leading-tight">Use Current Location</div>
              <div className="text-[10px] text-emerald-700 font-normal mt-0.5">
                Using device GPS triangulation
              </div>
            </div>
          </button>

          {/* City Selection Pills */}
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2">
              Popular Cities
            </span>
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
              {CITIES_LIST.map((c) => (
                <button
                  key={c.name}
                  id={`city-select-${c.name.replace(/\s+/g, '-')}`}
                  onClick={() => setSelectedCity(c.name)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 border transition-all ${
                    selectedCity === c.name
                      ? 'bg-neutral-900 text-white border-neutral-900 shadow-xs'
                      : 'bg-neutral-100 text-neutral-700 border-neutral-200 hover:bg-neutral-200'
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          {/* Search Area */}
          <div className="relative">
            <div className="flex items-center bg-neutral-100 rounded-xl px-3 py-2 border border-neutral-200">
              <Search className="w-4 h-4 text-neutral-400 mr-2 shrink-0" />
              <input
                id="search-locality-input"
                type="text"
                placeholder={`Search area in ${selectedCity}...`}
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="w-full text-xs font-medium bg-transparent focus:outline-none placeholder:text-neutral-400"
              />
            </div>
          </div>

          {/* Areas List */}
          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-1">
              Neighborhoods in {selectedCity}
            </span>
            <div className="divide-y divide-neutral-100">
              {filteredAreas.map((area) => {
                const isSelected =
                  selectedLocation.city === selectedCity &&
                  selectedLocation.area === area;

                return (
                  <button
                    key={area}
                    id={`area-btn-${area.replace(/\s+/g, '-')}`}
                    onClick={() => handleSelectArea(selectedCity, area)}
                    className="w-full py-2.5 px-2 flex items-center justify-between text-left hover:bg-neutral-50 rounded-lg transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-neutral-400" />
                      <span className="text-xs font-semibold text-neutral-800">
                        {area}
                      </span>
                    </div>
                    {isSelected && (
                      <Check className="w-4 h-4 text-emerald-600 font-bold" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
