import React, { useState } from 'react';
import {
  X,
  Phone,
  MessageSquare,
  Send,
  Mic,
  MicOff,
  Volume2,
  PhoneOff,
  Star,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface ChatMessage {
  id: string;
  sender: 'user' | 'partner';
  text: string;
  time: string;
}

export const PartnerContactModal: React.FC = () => {
  const {
    isPartnerModalOpen,
    setIsPartnerModalOpen,
    partnerModalBooking,
  } = useApp();

  const [mode, setMode] = useState<'chat' | 'call'>('chat');
  const [inputText, setInputText] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeaker, setIsSpeaker] = useState(false);
  const [callDuration, setCallDuration] = useState('00:24');

  const partner = partnerModalBooking?.partner;

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'partner',
      text: 'Namaste! I am your QuickServe service professional. I am carrying a sanitized kit and will arrive punctually.',
      time: 'Just now',
    },
  ]);

  if (!isPartnerModalOpen || !partnerModalBooking || !partner) return null;

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: text.trim(),
      time: 'Now',
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputText('');

    // Simulate partner response
    setTimeout(() => {
      const partnerReplies = [
        'Understood! I will reach your door shortly.',
        'Noted sir! I am just 5 minutes away.',
        'Sure, will call upon reaching the main gate.',
      ];
      const randomReply =
        partnerReplies[Math.floor(Math.random() * partnerReplies.length)];

      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'partner',
          text: randomReply,
          time: 'Now',
        },
      ]);
    }, 1200);
  };

  const quickReplies = [
    'Please call when at gate',
    'Doorbell not working, please knock',
    'How much time will you take?',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-xs p-0 sm:p-4">
      <div
        className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-3.5 bg-neutral-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <img
              src={partner.avatar}
              alt={partner.name}
              className="w-9 h-9 rounded-full object-cover ring-2 ring-emerald-400"
              referrerPolicy="no-referrer"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white">{partner.name}</span>
                <span className="text-[9px] bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.2 rounded border border-emerald-500/30">
                  Online
                </span>
              </div>
              <div className="text-[10px] text-neutral-400 flex items-center gap-1">
                <Star className="w-2.5 h-2.5 text-amber-400 fill-amber-400" />
                <span>{partner.rating} ★ • Verified Partner</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Mode Switcher */}
            <div className="bg-neutral-800 p-0.5 rounded-lg flex items-center border border-neutral-700">
              <button
                id="contact-mode-chat"
                onClick={() => setMode('chat')}
                className={`p-1.5 rounded-md text-xs transition-colors ${
                  mode === 'chat' ? 'bg-neutral-700 text-white' : 'text-neutral-400'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
              </button>
              <button
                id="contact-mode-call"
                onClick={() => setMode('call')}
                className={`p-1.5 rounded-md text-xs transition-colors ${
                  mode === 'call' ? 'bg-emerald-600 text-white' : 'text-neutral-400'
                }`}
              >
                <Phone className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              id="close-contact-modal-btn"
              onClick={() => setIsPartnerModalOpen(false)}
              className="p-1 hover:bg-neutral-800 rounded-full text-neutral-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content based on Mode */}
        {mode === 'chat' ? (
          <div className="flex-1 flex flex-col overflow-hidden bg-neutral-50">
            {/* Messages Scroll Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex flex-col ${
                    m.sender === 'user' ? 'items-end' : 'items-start'
                  }`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed ${
                      m.sender === 'user'
                        ? 'bg-neutral-900 text-white rounded-br-xs'
                        : 'bg-white text-neutral-900 border border-neutral-200 shadow-2xs rounded-bl-xs'
                    }`}
                  >
                    {m.text}
                  </div>
                  <span className="text-[9px] text-neutral-400 mt-1 px-1">{m.time}</span>
                </div>
              ))}
            </div>

            {/* Quick response chips */}
            <div className="p-2 bg-white border-t border-neutral-100 flex gap-1.5 overflow-x-auto no-scrollbar">
              {quickReplies.map((chip, idx) => (
                <button
                  key={idx}
                  id={`quick-reply-chip-${idx}`}
                  onClick={() => handleSendMessage(chip)}
                  className="px-2.5 py-1 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-[10px] font-medium shrink-0 transition-colors border border-neutral-200"
                >
                  {chip}
                </button>
              ))}
            </div>

            {/* Input Bar */}
            <div className="p-3 bg-white border-t border-neutral-200 flex items-center gap-2">
              <input
                id="partner-chat-input"
                type="text"
                placeholder="Type message to professional..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1 text-xs px-3 py-2 bg-neutral-100 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-900"
              />
              <button
                id="partner-chat-send-btn"
                onClick={() => handleSendMessage()}
                className="p-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          /* Phone Call Screen */
          <div className="flex-1 flex flex-col items-center justify-between p-8 bg-neutral-950 text-white min-h-[360px]">
            <div className="text-center space-y-2 mt-4">
              <div className="w-24 h-24 rounded-full overflow-hidden mx-auto ring-4 ring-emerald-500/40 shadow-2xl animate-pulse">
                <img
                  src={partner.avatar}
                  alt={partner.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <h3 className="text-lg font-bold text-white">{partner.name}</h3>
              <p className="text-xs text-neutral-400">QuickServe Professional</p>
              <div className="text-xs font-mono font-bold text-emerald-400">
                Connected • {callDuration}
              </div>
            </div>

            {/* Call Controls */}
            <div className="flex items-center gap-6 mb-4">
              <button
                id="call-mute-btn"
                onClick={() => setIsMuted(!isMuted)}
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                  isMuted ? 'bg-white text-neutral-950' : 'bg-neutral-800 text-white'
                }`}
              >
                {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>

              <button
                id="call-end-btn"
                onClick={() => setMode('chat')}
                className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg transition-colors"
              >
                <PhoneOff className="w-6 h-6" />
              </button>

              <button
                id="call-speaker-btn"
                onClick={() => setIsSpeaker(!isSpeaker)}
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                  isSpeaker ? 'bg-white text-neutral-950' : 'bg-neutral-800 text-white'
                }`}
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
