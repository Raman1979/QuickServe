import React, { useEffect, useRef, useState, useMemo } from 'react';
import L from 'leaflet';
import {
  Navigation,
  Play,
  Pause,
  RotateCcw,
  Zap,
  Crosshair,
  MapPin,
  Clock,
  Gauge,
  CheckCircle2,
} from 'lucide-react';
import { Address, ProfessionalPartner } from '../types';

interface Coordinate {
  lat: number;
  lng: number;
}

interface PartnerTrackingMapProps {
  address: Address;
  partner?: ProfessionalPartner;
  status: string;
  onPartnerArrived?: () => void;
}

// Coordinate resolvers based on Indian major cities
const getCityBaseCoords = (city: string): { dest: Coordinate; start: Coordinate; areaName: string } => {
  const norm = (city || '').toLowerCase();
  if (norm.includes('delhi') || norm.includes('noida') || norm.includes('gurgaon')) {
    return {
      dest: { lat: 28.6328, lng: 77.2197 },
      start: { lat: 28.6180, lng: 77.2020 },
      areaName: 'Connaught Place Hub',
    };
  }
  if (norm.includes('mumbai') || norm.includes('thane') || norm.includes('navi')) {
    return {
      dest: { lat: 19.0600, lng: 72.8360 },
      start: { lat: 19.0480, lng: 72.8530 },
      areaName: 'Bandra West Hub',
    };
  }
  if (norm.includes('hyderabad')) {
    return {
      dest: { lat: 17.4399, lng: 78.3908 },
      start: { lat: 17.4260, lng: 78.4090 },
      areaName: 'Madhapur Tech Hub',
    };
  }
  if (norm.includes('pune')) {
    return {
      dest: { lat: 18.5362, lng: 73.8940 },
      start: { lat: 18.5210, lng: 73.8780 },
      areaName: 'Koregaon Park Hub',
    };
  }
  if (norm.includes('chennai')) {
    return {
      dest: { lat: 13.0400, lng: 80.2500 },
      start: { lat: 13.0250, lng: 80.2350 },
      areaName: 'T. Nagar Hub',
    };
  }
  // Default to Bengaluru (Indiranagar / Domlur)
  return {
    dest: { lat: 12.9784, lng: 77.6408 },
    start: { lat: 12.9645, lng: 77.6185 },
    areaName: 'Indiranagar QuickServe Hub',
  };
};

// Generate realistic street turns / waypoints between start and destination
const generateRoutePoints = (start: Coordinate, dest: Coordinate): Coordinate[] => {
  const latDiff = dest.lat - start.lat;
  const lngDiff = dest.lng - start.lng;

  // Intermediary turns simulating city avenues & bypasses
  return [
    start,
    { lat: start.lat + latDiff * 0.12, lng: start.lng + lngDiff * 0.05 },
    { lat: start.lat + latDiff * 0.25, lng: start.lng + lngDiff * 0.28 },
    { lat: start.lat + latDiff * 0.38, lng: start.lng + lngDiff * 0.32 },
    { lat: start.lat + latDiff * 0.52, lng: start.lng + lngDiff * 0.58 },
    { lat: start.lat + latDiff * 0.65, lng: start.lng + lngDiff * 0.62 },
    { lat: start.lat + latDiff * 0.80, lng: start.lng + lngDiff * 0.85 },
    { lat: start.lat + latDiff * 0.92, lng: start.lng + lngDiff * 0.96 },
    dest,
  ];
};

// Calculate Haversine distance in km
const getDistanceKm = (c1: Coordinate, c2: Coordinate) => {
  const R = 6371; // Earth's radius in km
  const dLat = ((c2.lat - c1.lat) * Math.PI) / 180;
  const dLng = ((c2.lng - c1.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((c1.lat * Math.PI) / 180) *
      Math.cos((c2.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

// Interpolate between waypoints given progress t [0, 1]
const getPointAlongRoute = (route: Coordinate[], t: number): { point: Coordinate; angle: number } => {
  if (t <= 0) return { point: route[0], angle: 0 };
  if (t >= 1) return { point: route[route.length - 1], angle: 0 };

  const segmentCount = route.length - 1;
  const scaled = t * segmentCount;
  const segIdx = Math.min(Math.floor(scaled), segmentCount - 1);
  const segT = scaled - segIdx;

  const p1 = route[segIdx];
  const p2 = route[segIdx + 1];

  const lat = p1.lat + (p2.lat - p1.lat) * segT;
  const lng = p1.lng + (p2.lng - p1.lng) * segT;

  const y = Math.sin(((p2.lng - p1.lng) * Math.PI) / 180) * Math.cos((p2.lat * Math.PI) / 180);
  const x =
    Math.cos((p1.lat * Math.PI) / 180) * Math.sin((p2.lat * Math.PI) / 180) -
    Math.sin((p1.lat * Math.PI) / 180) *
      Math.cos((p2.lat * Math.PI) / 180) *
      Math.cos(((p2.lng - p1.lng) * Math.PI) / 180);
  const angle = (Math.atan2(y, x) * 180) / Math.PI;

  return { point: { lat, lng }, angle };
};

export const PartnerTrackingMap: React.FC<PartnerTrackingMapProps> = ({
  address,
  partner,
  status,
  onPartnerArrived,
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const partnerMarkerRef = useRef<L.Marker | null>(null);
  const completedPolylineRef = useRef<L.Polyline | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1);
  const [progress, setProgress] = useState<number>(0.25); // Start on the way
  const [isMapLoaded, setIsMapLoaded] = useState<boolean>(false);

  const cityCoords = useMemo(() => getCityBaseCoords(address.city), [address.city]);
  const routePoints = useMemo(
    () => generateRoutePoints(cityCoords.start, cityCoords.dest),
    [cityCoords]
  );

  const totalRouteDistance = useMemo(() => {
    let sum = 0;
    for (let i = 0; i < routePoints.length - 1; i++) {
      sum += getDistanceKm(routePoints[i], routePoints[i + 1]);
    }
    return sum;
  }, [routePoints]);

  const currentLoc = useMemo(
    () => getPointAlongRoute(routePoints, progress),
    [routePoints, progress]
  );

  const remainingKm = useMemo(() => {
    return Math.max(0, totalRouteDistance * (1 - progress));
  }, [totalRouteDistance, progress]);

  const etaMinutes = useMemo(() => {
    if (progress >= 0.98 || status === 'in-progress' || status === 'completed') return 0;
    // Assume average city scooter speed 25 km/h
    return Math.max(1, Math.round((remainingKm / 25) * 60));
  }, [remainingKm, progress, status]);

  // Handle live movement simulation loop
  useEffect(() => {
    if (!isPlaying) return;
    if (progress >= 1) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        const step = 0.006 * speedMultiplier;
        const next = prev + step;
        if (next >= 1) {
          if (onPartnerArrived) {
            onPartnerArrived();
          }
          return 1;
        }
        return next;
      });
    }, 200);

    return () => clearInterval(interval);
  }, [isPlaying, speedMultiplier, progress, onPartnerArrived]);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    try {
      const map = L.map(mapContainerRef.current, {
        center: [cityCoords.dest.lat, cityCoords.dest.lng],
        zoom: 14,
        zoomControl: false,
        attributionControl: false,
      });

      // OpenStreetMap clean standard tile layer
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
      }).addTo(map);

      // Add full route polyline (neutral/gray for remaining)
      const fullRouteCoords: [number, number][] = routePoints.map((p) => [p.lat, p.lng]);
      L.polyline(fullRouteCoords, {
        color: '#94a3b8',
        weight: 4,
        dashArray: '6, 8',
        opacity: 0.8,
      }).addTo(map);

      // Traveled route polyline (QuickServe / emerald green)
      const completedPoly = L.polyline([], {
        color: '#10b981',
        weight: 5,
        opacity: 0.95,
      }).addTo(map);
      completedPolylineRef.current = completedPoly;

      // Destination Marker (User's Home)
      const homeIcon = L.divIcon({
        className: 'custom-home-pin',
        html: `
          <div class="relative flex items-center justify-center">
            <div class="absolute -inset-2 bg-emerald-500/20 rounded-full animate-ping"></div>
            <div class="w-9 h-9 bg-neutral-900 text-white rounded-full flex items-center justify-center shadow-lg border-2 border-white ring-2 ring-emerald-500">
              <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
              </svg>
            </div>
            <div class="absolute -bottom-6 whitespace-nowrap bg-neutral-900/90 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">
              ${address.label}: ${address.flatNo || address.building || 'Home'}
            </div>
          </div>
        `,
        iconSize: [36, 36],
        iconAnchor: [18, 18],
      });

      L.marker([cityCoords.dest.lat, cityCoords.dest.lng], { icon: homeIcon }).addTo(map);

      // Origin Hub Marker (Nearby QuickServe Service Hub)
      const hubIcon = L.divIcon({
        className: 'custom-hub-pin',
        html: `
          <div class="relative flex items-center justify-center">
            <div class="w-7 h-7 bg-white text-neutral-800 rounded-full flex items-center justify-center shadow-md border-2 border-neutral-300">
              <span class="text-[9px] font-black font-mono text-neutral-700">QS</span>
            </div>
            <div class="absolute -bottom-5 whitespace-nowrap bg-white/90 text-neutral-700 text-[9px] font-semibold px-1.5 py-0.2 rounded border border-neutral-200">
              ${cityCoords.areaName}
            </div>
          </div>
        `,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });

      L.marker([cityCoords.start.lat, cityCoords.start.lng], { icon: hubIcon }).addTo(map);

      // Moving Partner Marker (QuickServe Professional on Scooter)
      const partnerIcon = L.divIcon({
        className: 'custom-partner-marker',
        html: `
          <div id="leaflet-partner-node" class="relative flex items-center justify-center transition-transform duration-200">
            <div class="w-10 h-10 rounded-full bg-amber-400 p-0.5 shadow-xl ring-2 ring-neutral-900">
              <img src="${partner?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}" class="w-full h-full rounded-full object-cover" />
            </div>
            <div class="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-white flex items-center justify-center">
              <span class="w-1.5 h-1.5 bg-white rounded-full"></span>
            </div>
            <div class="absolute -bottom-5 bg-amber-400 text-neutral-950 font-black text-[9px] px-1.5 py-0.2 rounded shadow-xs border border-amber-500 whitespace-nowrap">
              ${partner?.name?.split(' ')[0] || 'Partner'} • 🛵
            </div>
          </div>
        `,
        iconSize: [40, 40],
        iconAnchor: [20, 20],
      });

      const partnerMarker = L.marker([currentLoc.point.lat, currentLoc.point.lng], {
        icon: partnerIcon,
        zIndexOffset: 1000,
      }).addTo(map);

      partnerMarkerRef.current = partnerMarker;

      // Fit map view to bounds
      const bounds = L.latLngBounds([
        [cityCoords.start.lat, cityCoords.start.lng],
        [cityCoords.dest.lat, cityCoords.dest.lng],
      ]);
      map.fitBounds(bounds, { padding: [40, 40] });

      mapInstanceRef.current = map;
      setIsMapLoaded(true);
    } catch (err) {
      console.error('Error initializing Leaflet map:', err);
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [cityCoords, routePoints, address, partner]);

  // Update partner marker position and completed polyline as progress changes
  useEffect(() => {
    if (!partnerMarkerRef.current || !mapInstanceRef.current) return;

    partnerMarkerRef.current.setLatLng([currentLoc.point.lat, currentLoc.point.lng]);

    // Update traveled line
    if (completedPolylineRef.current) {
      const traveledPoints: [number, number][] = [];
      const segmentCount = routePoints.length - 1;
      const currentSegment = Math.floor(progress * segmentCount);

      for (let i = 0; i <= currentSegment && i < routePoints.length; i++) {
        traveledPoints.push([routePoints[i].lat, routePoints[i].lng]);
      }
      traveledPoints.push([currentLoc.point.lat, currentLoc.point.lng]);
      completedPolylineRef.current.setLatLngs(traveledPoints);
    }
  }, [currentLoc, progress, routePoints]);

  const handleCenterOnPartner = () => {
    if (!mapInstanceRef.current) return;
    mapInstanceRef.current.setView([currentLoc.point.lat, currentLoc.point.lng], 16, {
      animate: true,
    });
  };

  const handleCenterFullRoute = () => {
    if (!mapInstanceRef.current) return;
    const bounds = L.latLngBounds([
      [cityCoords.start.lat, cityCoords.start.lng],
      [cityCoords.dest.lat, cityCoords.dest.lng],
    ]);
    mapInstanceRef.current.fitBounds(bounds, { padding: [40, 40], animate: true });
  };

  const handleResetSimulation = () => {
    setProgress(0.05);
    setIsPlaying(true);
  };

  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-neutral-200 bg-neutral-100 shadow-inner flex flex-col">
      {/* Top Floating ETA & Status HUD */}
      <div className="absolute top-3 inset-x-3 z-20 flex items-center justify-between pointer-events-none">
        <div className="pointer-events-auto bg-neutral-900/90 backdrop-blur-md text-white rounded-xl px-3 py-2 shadow-lg border border-white/10 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <Navigation className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-extrabold text-white">
                {progress >= 0.98 ? 'Partner Has Arrived!' : `Arriving in ~${etaMinutes} mins`}
              </span>
              <span className="text-[9px] bg-emerald-500 text-neutral-950 font-black px-1 rounded uppercase">
                Live
              </span>
            </div>
            <div className="text-[10px] text-neutral-300 flex items-center gap-2 mt-0.5 font-medium">
              <span className="flex items-center gap-0.5">
                <MapPin className="w-3 h-3 text-neutral-400" />
                {progress >= 0.98 ? 'At your doorstep' : `${remainingKm.toFixed(1)} km away`}
              </span>
              <span>•</span>
              <span className="flex items-center gap-0.5">
                <Gauge className="w-3 h-3 text-neutral-400" />
                {progress >= 0.98 ? '0 km/h' : '28 km/h'}
              </span>
            </div>
          </div>
        </div>

        {/* Map Center Controls */}
        <div className="pointer-events-auto flex flex-col gap-1.5">
          <button
            type="button"
            id="center-partner-btn"
            onClick={handleCenterOnPartner}
            title="Focus on partner"
            className="p-2 bg-white/95 backdrop-blur-xs text-neutral-800 rounded-xl shadow-md hover:bg-white transition-colors border border-neutral-200"
          >
            <Crosshair className="w-4 h-4 text-emerald-600" />
          </button>
          <button
            type="button"
            id="center-route-btn"
            onClick={handleCenterFullRoute}
            title="View entire route"
            className="p-2 bg-white/95 backdrop-blur-xs text-neutral-800 rounded-xl shadow-md hover:bg-white transition-colors border border-neutral-200"
          >
            <Navigation className="w-4 h-4 text-neutral-700" />
          </button>
        </div>
      </div>

      {/* Leaflet Map DOM Canvas */}
      <div
        id="leaflet-tracking-map-container"
        ref={mapContainerRef}
        className="w-full h-64 sm:h-72 z-10"
        style={{ minHeight: '260px' }}
      />

      {/* Bottom Interactive Simulation Controls Bar */}
      <div className="p-2.5 bg-white border-t border-neutral-200 z-20 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 w-full sm:w-auto justify-between sm:justify-start">
          <div className="flex items-center gap-1">
            <button
              type="button"
              id="sim-play-pause-btn"
              onClick={() => setIsPlaying(!isPlaying)}
              className="px-2.5 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition-colors"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-3 h-3 text-amber-400" />
                  <span>Pause</span>
                </>
              ) : (
                <>
                  <Play className="w-3 h-3 text-emerald-400" />
                  <span>Resume</span>
                </>
              )}
            </button>

            <button
              type="button"
              id="sim-speed-btn"
              onClick={() =>
                setSpeedMultiplier((prev) => (prev === 1 ? 2 : prev === 2 ? 5 : 1))
              }
              className="px-2 py-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 rounded-lg text-xs font-bold flex items-center gap-0.5 transition-colors"
              title="Change simulation speed"
            >
              <Zap className="w-3 h-3 text-amber-500" />
              <span>{speedMultiplier}x</span>
            </button>

            <button
              type="button"
              id="sim-reset-btn"
              onClick={handleResetSimulation}
              className="p-1.5 text-neutral-500 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors"
              title="Restart route simulation"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="text-[11px] font-bold text-neutral-600 flex items-center gap-1">
            <span>Route progress:</span>
            <span className="font-mono text-emerald-600">{Math.round(progress * 100)}%</span>
          </div>
        </div>

        {/* Progress Slider */}
        <div className="w-full sm:w-44 flex items-center gap-2">
          <input
            id="simulation-progress-slider"
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={progress}
            onChange={(e) => {
              setIsPlaying(false);
              setProgress(parseFloat(e.target.value));
            }}
            className="w-full h-1.5 bg-neutral-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
          />
        </div>
      </div>
    </div>
  );
};
