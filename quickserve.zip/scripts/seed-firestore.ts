import { uploadServicesToFirestore } from '../src/lib/firestoreSeed';

async function run() {
  console.log('Starting seed of all QuickServe services to Firestore...');
  try {
    const result = await uploadServicesToFirestore();
    console.log(`Successfully uploaded ${result.count} services to Firestore!`);
    process.exit(0);
  } catch (error) {
    console.error('Error seeding services:', error);
    process.exit(1);
  }
}

run();
